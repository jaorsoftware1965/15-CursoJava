import java.io.IOException;
import java.io.RandomAccessFile;

import javax.sound.sampled.AudioFormat.Encoding;


public class c40_archivos_acceso_aleatorio_final {

	public static void main(String[] args) throws IOException 
	{	
		// -------------------------------------------------
		// Clase 40 - Archivos de Acceso Aleatorio Final
		// Autor - JAOR
		// www.jaorsoftware.cu.cc
		// -------------------------------------------------
		
	    // Esta Clase es la Final de este curso de fundamentos
		// de JAVA.
		
		// Es esta clase veremos como realizar Escritura y Lectura
		// de tipos de datos Nativos como son byte[],char,int,float y double.
		
		// Aprenderemos cuantos bytes ocupa en disco, cada tipo de dato
		// cuando es grabado.		

    	// Declaración de Variables
    	byte[]   arrbNombre=new byte[12];
    	float    fPeso;
    	int      iEdad;
    	Double   dEstatura;
    	char     cActivo;
    	

    	// Coloca información en la Persona
    	arrbNombre="Jose Esteper".getBytes();  // 12 Bytes
    	fPeso=290.50f;                         //  4 Bytes
    	iEdad=94;                              //  4 Bytes
    	dEstatura=2.22;                        //  8 Bytes
    	cActivo='S';                           //  2 Bytes
    	                                       // --------
    	                                       // 30 Bytes
    	
        // Longitud del Registros
    	int iLonRegistro=30;
    	
		// Declaramos un Objeto para el Archivo
        RandomAccessFile xFileAleatorio = null;
        
		System.out.println("Abriendo el Archivo...");
		xFileAleatorio = new RandomAccessFile( "Datos.txt","rw");		
		System.out.println("Longitud del Archivo   :"+xFileAleatorio.length());
		System.out.println("Registros en el Archivo:"+xFileAleatorio.length()/iLonRegistro);
		
		// Colocandonos en el final del Archivo
		System.out.println("Ubicandonos al Final del Archivo...");
		xFileAleatorio.seek(xFileAleatorio.length());
	
		System.out.println("Grabando un Registro al Final del Archivo...");		
		// Graba un Registro
		xFileAleatorio.write(arrbNombre);
	    xFileAleatorio.writeFloat( fPeso );
	    xFileAleatorio.writeInt( iEdad );
	    xFileAleatorio.writeDouble( dEstatura );
	    xFileAleatorio.writeChar( cActivo );
		
	    // Leyendo un Registro Determinado
		System.out.println("Ubicandonos en un Registro ...");
	    xFileAleatorio.seek((1-1)*iLonRegistro);
	    
		System.out.println("Leyendo el Registro...");
		xFileAleatorio.read(arrbNombre);
	    fPeso=xFileAleatorio.readFloat();
	    iEdad=xFileAleatorio.readInt();
	    dEstatura=xFileAleatorio.readDouble();
	    cActivo=xFileAleatorio.readChar();
	    
	    // Desplegando
		System.out.println("Desplegando el Regitro ...");
		System.out.println(new String(arrbNombre, "UTF-8"));
		System.out.println(fPeso);
		System.out.println(iEdad);
		System.out.println(dEstatura);
		System.out.println(cActivo);
	    	 		
	    // Cierra los Flujos
		System.out.println("Cerrando los Flujos");
     	xFileAleatorio.close();
				
		// Fin del Programa
		System.out.println("Fin de la Aplicación");

	}
}
