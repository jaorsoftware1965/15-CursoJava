
public class c17_procedimientos {
    int iTabla=7;

    @SuppressWarnings("static-access")
	public static void main(String[] args) {
        
        // Clase 17. Procedimientos y  Variables Locales
        // Un Procedimiento en un conjunto de instrucciones que realizan una funci�n especifica; y a la cual se le
        // asocia un nombre con el cual puede ser "llamado o invocado" para su ejecuci�n.
        // Al igual que con las variables, se tiene que indicar de que tipo son, y los procedimientos siempre son
        // del tipo "void"; es decir; que no devuelven resultado alguno; simplemente realizan algo.
        // Si el procedimento es de tipo static, puede ser llamado sin crear una istancia de la clase; si no son
        // static, entonces es necesario crear una instancia de la clase
        
        // Variable local al procedimiento main
        int iTabla=10;
                
        // Desplegando Mensaje
        sbMensaje();
        sbTabla();
        
        // Creo una instancia de la clase para poder usar la funci�n
        c17_procedimientos xProcedimiento = new c17_procedimientos();
        
        // Llamo al procedimiento que ejecuta el mensaje
        xProcedimiento.sbMensaje();
        xProcedimiento.sbDespliegaMensaje();
        
        
        // Llamo al precedimiento que despliega la tabla
        xProcedimiento.sbTabla();
        xProcedimiento.sbDespliegaTabla();
                
        // Ciclo que imprime tabla de multiplicar
        System.out.println("El valor de tabla:"+iTabla);            
        
        
        
    }
    private static void sbMensaje() {        
        // Procedimiento para desplegar un Mensaje
        
        // Ciclo que imprime tabla de multiplicar
        System.out.println("Hola Mundo Static");
    }
    
    private static void sbTabla() {
        // Procedimiento para desplegar una tabla
        
        // Variables locales al procedimiento
        int iMultiplicador;
        int iTabla=5;
        
        // Ciclo que imprime tabla de multiplicar
        System.out.println("Primera Tabla Static");
        for (iMultiplicador=0;iMultiplicador <=10; iMultiplicador++)
        {
            // Evita impresi�n de la tabla para multiplicadoes pares
            if (iMultiplicador%2==0)
               continue;
            
            // Imprime la tabla
            System.out.println(iTabla+" X "+iMultiplicador + " = "+iTabla*iMultiplicador);
            
            // Sale si encuentra el 9
            if (iMultiplicador ==9)
               break;
            
        }
        System.out.println("");
        
    }    
    private void sbDespliegaMensaje() {        
        // Procedimiento para desplegar un Mensaje
        
        // Ciclo que imprime tabla de multiplicar
        System.out.println("Hola Mundo");
    }
    
    private  void sbDespliegaTabla() {
        // Procedimiento para desplegar una tabla
        
        // Variables locales al procedimiento
        int iMultiplicador;
        //int iTabla=5;
        
        // Ciclo que imprime tabla de multiplicar
        System.out.println("Primera Tabla");
        for (iMultiplicador=0;iMultiplicador <=10; iMultiplicador++)
        {
            // Evita impresi�n de la tabla para multiplicadoes pares
            if (iMultiplicador%2==0)
               continue;
            
            // Imprime la tabla
            System.out.println(iTabla+" X "+iMultiplicador + " = "+iTabla*iMultiplicador);
            
            // Sale si encuentra el 9
            if (iMultiplicador ==9)
               break;
            
        }
        System.out.println("");
        
    }    
}
