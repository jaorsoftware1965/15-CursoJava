
public class c14_estructura_control_switch {
    public static void main(String[] args) {
        
        // Clase 14. La sentencia switch. Esta sentencia nos permite evaluar una expresion y en base a ella 
        // tomar diferentes cursos en el flujo del programa. La expresión a evaluar puede ser una variable
        // de tipo byte,short,char, int y String; o una expresión que devuelva un resultado de cualquiera de
        // estos tipos
        
        // La sintaxis para utilizar esta expresion es la siguiente:
     
        //   switch (expresion)
        //   {   
        //       case valor1:
        //           bloque de instrucciones
        //           break;
        //       [case valor2:
        //           bloque de instrucciones
        //           break;
        //       ...]
        //       [default:
        //           bloque de instrucciones
        //          break;
        //       ]
        //   }
        
        // En la sintaxis podemos distinguir la sentencia switch y enseguida entre parentesis la expresion que se va a 
        // evaluar y devolver un resultado.
    	
        // Cada uno de los case, tienen un valor posible para expresion y en caso de que el valor de expresion
        // coincida con uno de estos valores, se ejecutará el bloque de instrucciones correspondientes.
        
    	// La sentencia break, debe ser indicada al final de cada bloque de instrucciones del case, para salir del
        // bloque de código del switch; aunque habrá casos en los que no será necesario usarlo.
        
        
        // Declaración de variables
        int    iEdad = 30;// Probar con 30,11
        
        switch (iEdad) // Agregar -15 en la expresi�n; y agregar 12.5 y ver que falla 
        { 
            default:
            System.out.println("La vida");    
            break;
        
            // Evaluamos cuando 1 y 2
	        case 1:
	        case 2:
	            System.out.println("Maternal");    
	            break;
	        case 3:
	        case 4:
	        case 5:
	            System.out.println("Kinder Garden");    
	            break;
	        case 6:
	        case 7:
	        case 8:
	        case 9:
	        case 10:
	        case 11:
	            System.out.println("Primaria");    
	            break; // Si colocamos edad 11 y quitamos el break, se continua
	        case 12:
	        case 13:
	        case 14:
	            System.out.println("Secundaria");    
	            break;
	                
	        case 15:
	        case 16:
	        case 17:
	            System.out.println("Bachillerato");    
	            break;
	        
	        case 18:
	        case 19:
	        case 20:
	        case 21:
	        case 22:
	            System.out.println("Universidad");    
	            break;
	        
	        case 23:
	        case 24:
	            System.out.println("Maestria");    
	            break;
	        
	        case 25:
	        case 26:
	            System.out.println("Doctorado");    
	            break;
	        
	        case 30:
	            System.out.println("Matrimonio");    
	            break;
        }
        
        
        // Declaro variable String
        String strNombre="Maria";
        
        switch(strNombre) {
            case "Juan":
                System.out.println("Apostol");    
                break;
            case "Jose":
                System.out.println("Padre de Jesús");    
                break;
            case "Maria":
                System.out.println("Madre de Jesús");    
                break;
            case "Pedro":// Si coloco Juan de nuevo, valida que los valores sean distintos
                System.out.println("Piedra de la Iglesia");    
                break;
            case "Herodes":
                System.out.println("El Rey Malo");    
                break;
        }       
        
        // Haz un switch para tipo char, y que me indique si la letra es una
        // vocal o una consonante
        char chrCaracter='Z';
        
        // Evaluamos la Letra
        switch (chrCaracter)
        {
        	case 'a':
        	case 'e':
        	case 'i':
        	case 'o':
        	case 'u':
        		System.out.println (chrCaracter + " Es una vocal minúscula");
        		break;
        	case 'A':
        	case 'E':
        	case 'I':
        	case 'O':
        	case 'U':
        		System.out.println (chrCaracter + " Es una vocal Mayúscula");
        		break;
        	case '0':
        	case '1':
        	case '2':
        	case '3':
        	case '4':
        	case '5':
        	case '6':
        	case '7':
        	case '8':
        	case '9':
        		System.out.println (chrCaracter + " Es un número");
        		break;
        	default:
        		System.out.println (chrCaracter + " No es una vocal ni un numero");
        }        
    }
}
