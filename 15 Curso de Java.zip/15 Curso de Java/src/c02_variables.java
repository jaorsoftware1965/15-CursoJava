
public class c02_variables {

    @SuppressWarnings("unused")
	public static void main(String[] args) {

        /* 
        Clase 02. Variables
        Las variables son espacios de memoria, en donde se deposita informaci�n
        El espacio de memoria debe indicarse de que tipo o clase es para saber que va a almacenar
        A los tipos o clases de memoria para almacenar informaci�n se les llama tipos de datos
        Los tipos de datos primitivos son: 
        - byte. 8 bits con signo. del -128 al 127
        - short. 16 bits con signo. -32768 al 32767 
        - int. 32 bits con signo. -2.147.483.648 .. 2.147.483.647
        - long. 64 bits con signo. -9.223.372.036.854.775.808 .. 9.223.372.036.854.775.807
        - float. 32 bits precision simple. 3.4e-038 .. 3.4e+038
        - double. 64 bits precision double. 1.7e-308 .. 1.7e+308
        - boolean. 8 bits. true - false
        - char. 16 bits sin signo. 0-65536

        Valores por Default 
        byte    0
        short   0
        int     0
        long    0L
        float   0.0f
        double  0.0d
        char    '\u0000'
        String (or any object)          null
        boolean false */
        
        byte byteVariable=0x55;
        short shortVariable=10;
        int intVariable=0;
        long longVariable = 45000;
        float floatVariable = 14.13f;
        float f2 = (float) 3.14;
        double doubleVariable = 45.799;
        boolean booleanVariable = false;
        char charVariable='a';
        
        Character CharacterVariable='j';
        String StringVariable="JaorSoftware";
        
        // Imprime las variables a la salida estandar
        System.out.println("Variable tipo byte:"+byteVariable);    
        System.out.println("Variable tipo short:"+shortVariable);    
        System.out.println("Variable tipo int:"+intVariable);    
        System.out.println("Variable tipo char:"+charVariable);
        System.out.println("Variable tipo boolean:"+booleanVariable);
        System.out.println("Variable tipo Character:"+CharacterVariable);
        System.out.println("Variable tipo String:"+StringVariable);        
        /**/
        
        // Asignaciones en las variables integer
        intVariable = 0x10;
        System.out.println("Variable tipo int:"+intVariable);    
        intVariable = 0b1001;
        
        // Asignado valores a doubles
        doubleVariable = 123.4;
        doubleVariable = 1.234e2;
        
        // Cast
        intVariable = (int) 5.14;
        System.out.println("Variable tipo int:"+intVariable);    
        
        shortVariable = (short) 32769;
        System.out.println("Variable tipo short:"+shortVariable);    
        
        // No es posible
        /*booleanVariable = (boolean)23;*/
                
    }

}
