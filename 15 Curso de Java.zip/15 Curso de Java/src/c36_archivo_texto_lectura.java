import java.io.BufferedReader;
import java.io.FileReader;


public class c36_archivo_texto_lectura {

	public static void main(String[] args) 
	{
		
		// ------------------------------------
        // Clase 36 - Archivos de Texto Lectura
		// Autor - JAOR
		// www.jaorsoftware.cu.cc
		// ------------------------------------
		
		// Es posible Clasificar todos los archivos de un Sistema Operativo
		// en 2 clases; archivos de Texto; y archivos de NO texto.
		
		// Los Archivos de texto, son aquellos en los cuales todo su contenido
		// puede ser interpretado como caracteres. Ejemplo mas claro; un archivo
		// generado por un Editor como NotePad o gEdit.
		
		// Los Archivos de NO TEXTO tambien conocidos como binarios; son aquellos
		// que su contenido, no puede ser procesado como Texto y no es posible 
		// visualizarlos correctamente como tal. Ejemplo; un archivo .EXE o 
		// un archivo de Imagen.
		
		// En esta clase veremos como poder realizar una Lectura de un Archivo de
		// Texto.
		
		// Utilizaremos la Clase FileReader vista en la clase anterior, además de utilizar
		// la Clase BufferedRead; la cual está diseñada específicamente para realizar
		// la lectura del Archivo.
	
		// Declaramos un Objeto de la Clase FileReader
		FileReader xFile;
		
		
		// Variable para Leer el Archivo
		BufferedReader xLector;

		// Variable de Tipo String
		String strLinea;
		
		// Capturamos el Error
		try 
		{
			// Accedemos alArchivo
		    xFile = new FileReader("prueba.txt");
		    
		    // Asociamos el objeto File al objeto de Lectura del Archivo
		    xLector = new BufferedReader(xFile);

		    // Inciamos Lectura por Linea
		    System.out.println("Lectura por Linea...");

		    // Ciclo para leer del Archivo
		    while((strLinea = xLector.readLine()) != null)
		    	System.out.println(strLinea);


		    // Cierra el Buffer y el Archivo
		    xLector.close();
		    xFile.close();
		    

		}
		catch(java.io.FileNotFoundException fnfex) 
		{
		   System.out.println("Archivo no encontrado: " + fnfex);
		}
		catch(java.io.IOException ioex) 
		{
			System.out.println("Archivo no encontrado: " + ioex.getMessage());			
		}
		
		// Deja un Espacio
		System.out.println("\n");
		
				

		// Definimos un Caracter
		int xChar;
		
		// Ciclo para leer del Archivo
	    int iCuenta=0;
	    
		// Capturamos el Error
		try 
		{
			// Accedemos alArchivo
		    xFile = new FileReader("prueba.txt");
		    
		    // Asociamos el objeto File al objeto de Lectura del Archivo
		    xLector = new BufferedReader(xFile);
    
		    // Saltamos 10
		    xLector.skip(10);
		    
		    // Iniciando Lectura por Caracter
		    System.out.println("Iniciando Lectura por Caracter...");
		    while((xChar = xLector.read())!=-1)
		    {	
		       	System.out.print((char)xChar);
		       	iCuenta++;
		    }
		    
		    // Longitud del Archivo
		    System.out.println("Longitud del Archivo:"+iCuenta);
		    
		    // Cierra el Buffer y el Archivo
		    xLector.close();
		    xFile.close();
		    
		}
		catch(java.io.FileNotFoundException fnfex) 
		{
		   System.out.println("Archivo no encontrado: " + fnfex);
		}
		catch(java.io.IOException ioex) 
		{
			System.out.println("Archivo no encontrado: " + ioex.getMessage());			
		}

	}
}
