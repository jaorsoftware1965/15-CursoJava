
// Declaramos una interface
interface Animal
{
	// Declaramos un solo método, pudieran ser mas
	public void sbEmiteSonido();
	
}

// Creamos una Clase llamada Perro que implementa la interface Animal
class Perro implements Animal
{
	// Define el Método Abstracto
	public void sbEmiteSonido()
	{
		// Despliega un Mensaje con el Sonido del Perro
		System.out.println("Ladrido");
	}
}

//Creamos otra Clase llamada Gato que implementa la interface Animal
class Gato implements Animal
{
	// Define el Método Abstracto
	public void sbEmiteSonido()
	{
		// Despliega un Mensaje con el Sonido del Gato
		System.out.println("Maullido");
	}
}

public class c32_interfaces {
	public static void main(String[] args) 
	{
        // Clase 32 - Interfaces
		
		// Una Interfaz es una Clase Abstracta, en donde es obligatorio que 
		// todos su métodos sean abstractos.
		
		// Como vimos en el tema de POO, una Clase Abstracta es aquella en
		// que por lo menos hay un método abstracto definido. 
		// Un método abstracto como hemos visto ya, no tiene Código.
		
		// Lo anterior quiere decir que cuando creamos un Interface, lo que 
		// hacemos es definir lo que la clase que la implemente podrá hacer, 
		// pero no indicamos la forma en que lo hará.

		// En java se usa la palabra reservada implements para indicar que 
		// implementamos una interface. La estructura general de una clase que 
		// implementa una interface es la siguiente.
		
		// interface InterfacePrincipal 
		// {
		// 	 public void   metodoAbstracto();
		// 	 public String otroMetodoAbstracto();
		// }
			 
		// public class Principal implements InterfacePrincipal,otraInterface,otraMas
		// {			 
		// 	 public void metodoAbstracto() 
		//   {
		// 	  /**Implementación definida por la clase concreta*/
		//   }
			 
		//   public String otroMetodoAbstracto() 
		//   {
		// 	    /**Implementación definida por la clase concreta*/
		// 	    return "retorno";
		//   }
			 
		//   public void metodoAbstractoDeOtraInterface() 
		//   {
		// 	    / **Implementación definida por la clase concreta*/
		//   }
			 
		//   public void metodoAbstractoDeOtraMas() 
		//   {
		//      /**Implementación definida por la clase concreta*/
		//   }
		
		// Como se observa, la clase Principal implementa 3 interfaces.
		
		// Características de las Interfaces.

		// Todos los métodos de una interfaz son implícitamente public abstract,
		// no es necesario especificarlo en la declaración del mismo.
		
		// Todas las variables y atributos de una interfaz son implícitamente 
		// constantes (public static final), no es necesario especificarlo en 
		// la declaración del misma.
		
		// Los métodos de una interfaz no pueden ser: static, final, strictfp 
		// ni native.
		
		// Una interfaz puede heredar (extends) de una o más interfaces.

		// Una interfaz no puede heredar de otro elemento que no sea una 
		// interfaz.

		// Una interfaz no puede implementar (implements) otra interfaz.
		
		// Una interfaz debe ser declarada con la palabra clave interface.
				
		// Define un objeto de la Clase Perro	
    	Perro xPerro = new Perro();
    	
    	// Llamamos al Método para Emitir Sonido del Perro
    	xPerro.sbEmiteSonido();
    	
    	// Define un objeto de la Clase Gato
    	Gato  xGato  = new Gato();

    	// Llamamos al M�todo para Emitir Sonido del Gato
    	xGato.sbEmiteSonido();    	
    }
}
