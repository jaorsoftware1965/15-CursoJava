import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;


public class c38_archivos_aleatorios_escritura {
	
	// -------------------------------------------------
	// Clase 38 - Archivos de Acceso Aleatorio Escritura
	// Autor - JAOR
	// www.jaorsoftware.cu.cc
	// -------------------------------------------------
	
    // En las 2 Clases anteriores hemos visto como acceder a un archivo
	// y leer o escribir desde el principio; pero sin poder seleccionar
	// en forma aleatoria un lugar en específico. Es decir.
	
	// Podemos tener la necesidad de leer y escribir información en diferentes
	// partes de un archivo; y sin un orden específico. Con los 2 metodos
	// vistos anteriormente no es posible.
	
	// Entonces lo que necesitamos es poder acceder a un archivo en una posición
	// aleatoria; es decir; puede ser cualquier posición dentro del archivo.
	// A esta forma de acceso se le conoce como Acceso Directo o Aleatorio.
	
	// Java proporciona una Clase para este propósito llamada RandomAccessFile.
	// Con esta clase podemos leer y escribir en cualquier parte del archivo
	// y desplazarnos hacia adelante y hacia atrás del mismo.
	
	// En esta clase veremos como escribir datos en un Archivo Aleatorio; en
	// diversas posiciones del Archivo.
	
	// Función Principal
	@SuppressWarnings("unused")
	public static void main( String args[] ) 
	{
		
		// Declaramos un Objeto de la Clase
        RandomAccessFile xFileAleatorio;
        
        // Información a grabar en el archivo
        // Arreglo para almanenar 10 calificaciones
        String strCodigo="9999";       //  4 Caracteres
        String strNombre="Juan Perez"; // 10 Caracteres
        String strEdad  ="45";         //  2 Caracteres
        String strPeso  ="79.50";      //  5 Caracteres
        String strActivo=" ";          //  1 Caracter
        String strEOL   ="\n";         //  1 Caracter
        int iLongitud=23;              // 23 Longitud del Registro

    	        
        // Captura de Excepciones 
        try 
        {
        	        	
        	// Creamos el Archivo de Acceso Directo
        	xFileAleatorio = new RandomAccessFile( "Datos.txt","rw" );
            
        	// Desplegamos su longitud
        	System.out.println("Longitud del Archivo:"+xFileAleatorio.length());
        	System.out.println("Registros del Archivo:"+xFileAleatorio.length()/23);
        	
            // Nos vamos al final del fichero
        	xFileAleatorio.seek( xFileAleatorio.length() );
        	
        	// Nos movemos al principio del Registro y Modificamos el Registro
        	//xFileAleatorio.seek(0);

        	// Nos movemos a un registro específico y Modificamos el Registro
        	//int iRegistro=3;
        	
        	//xFileAleatorio.seek((iRegistro-1)*iLongitud);

		    // Incorporamos la cadena al fichero     
            xFileAleatorio.writeBytes( strCodigo );
            xFileAleatorio.writeBytes( strNombre );
            xFileAleatorio.writeBytes( strEdad );
            xFileAleatorio.writeBytes( strPeso );
            xFileAleatorio.writeBytes( strActivo );
            xFileAleatorio.writeBytes( strEOL );
            
            // Mensaje
            System.out.println("Se ha grabado un Registro en el Archivo");
                        
            // Cerramos el fichero
            xFileAleatorio.close();
            
		} 
        catch (FileNotFoundException e) 
        {
			e.printStackTrace();
		}
        catch (IOException e) {
			e.printStackTrace();
		}
        
    }
}
