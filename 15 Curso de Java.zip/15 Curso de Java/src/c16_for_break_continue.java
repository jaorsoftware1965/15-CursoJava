
public class c16_for_break_continue {
    public static void main(String[] args) {        
        // Clase 16. Estructuras de Control IV. Ciclo for, break y continue
        // El ciclo for es una estructura avanzada y simplificada de implementar un ciclo while. Al igual que las
        // estructuras anteriores, nos permite ejecutar un ciclo basado en una condici�n; que por lo general es
        // una condici�n que implica un proceso repetitivo basado en el incremento o decremento de una variable
        // num�rica; aunque no necesariamente debe ser as�.
        // La sintaxis del ciclo for es la siguiente:
        
        // for (inicializacion; condicion; incremento-decremento)
        // {
        //     bloque de instrucciones;
        // }
    
    
        // en donde:
        // inicializaci�n es una variable entera a la cual se le asigna un valor inicial
        // condici�n: es la condici�n basada en la variable de inicializaci�n y en el incremento-decremento
        // incremento-decremento: es la indicaci�n del incremento o decremento que se aplica a la variable
        // de inicializaci�n para que en algun punto de su valor, la condici�n ya no se cumpla y el ciclo
        // finalice
        
        int iTabla=5;
        int iMultiplicador=0;
        boolean bFuncionando=true;

     
        // Ciclo que imprime tabla de multiplicar
        System.out.println("Primera Tabla");
        for (iMultiplicador=0;iMultiplicador <=10; iMultiplicador++)
        {
            // Evita impresi�n de la tabla para multiplicadoes pares
            if (iMultiplicador%2==0)
               continue;
            
            // Imprime la tabla
            System.out.println(iTabla+" X "+iMultiplicador + " = "+iTabla*iMultiplicador);
            
            // Sale si encuentra el 9
            if (iMultiplicador ==9)
               break;
            
        }
        System.out.println("");
        
        
        // Ciclo que imprime tabla de multiplicar y que la condici�n no pertenece a la variable inicializaci�n
        System.out.println("Segunda Tabla");
        for (iMultiplicador=0;bFuncionando; iMultiplicador++)
        {
            // Evita impresi�n de la tabla para multiplicadoes pares
            if (iMultiplicador%2==0)
               continue;
            
            // Imprime la tabla
            System.out.println(iTabla+" X "+iMultiplicador + " = "+iTabla*iMultiplicador);
            
            // Sale si encuentra el 9
            if (iMultiplicador ==9)
               bFuncionando=false;
            
        }
        System.out.println("");
        
        // Ciclo que imprime tabla de multiplicar y que la inicializaci�n no tiene que ver con la condici�n
        System.out.println("Tercera Tabla");
        bFuncionando=true;
        for (iTabla=7;bFuncionando; iMultiplicador++)
        {
            // Evita impresi�n de la tabla para multiplicadoes pares
            if (iMultiplicador%2==0)
               continue;
            
            // Imprime la tabla
            System.out.println(iTabla+" X "+iMultiplicador + " = "+iTabla*iMultiplicador);
            
            // Sale si encuentra el 9
            if (iMultiplicador ==19)
               bFuncionando=false;
            
        }
    }
}
