import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;



public class c37_archivo_texto_escritura {

	public static void main(String[] args) 
	{
		// ------------------------------------------
        // Clase 37 - Escritura de Archivos de Texto
		// Autor - JAOR
		// www.jaorsoftware.cu.cc
		// ------------------------------------------
				
		// En esta clase veremos como poder realizar la Escritura de un Archivo de
		// Texto.
		
		// Utilizaremos la Clase FileWriter, que es la contraparte de la Clase FileReader
		// utilizada para leer archivos.
		
		// Utilizaremos la Clase BufferedWriter; contraparte de BufferedReader; la cual está 
		// diseñada específicamente para realizar escrituras en un archivo de Texto; y una
		// clase adicional llamada PrintWriter la cual nos permite grabar en el archivo 
		// utilizando la función tradicional println.
		
		// Captura el Error
		try 
		{
			// Variables para grabar en el Archivo
			int  xInt      = 345;
			char xChar     = 'X';
			float xFloat   = 123.56f;
			double xDouble = 456.34;
			
			// Variable para poder escribir en un Archivo
			FileWriter xFile = new FileWriter("Salida.txt",true);// Agregar true para append
			
			// Creamos el objeto para el Buffer de Escritura
			BufferedWriter xEscritor = new BufferedWriter(xFile);
			
			// Mensaje
			System.out.println("Grabando el Archivo Salida.txt");
			
			// Grabamos al Archivo
			xEscritor.write("Primera zzzLínea del Archivo\n");
			xEscritor.write("Segunda zzzLínea del Archivo\n");
			
			// Grabamos las Variables
			xEscritor.write(xInt);
			xEscritor.newLine();
			xEscritor.write(xChar);
			xEscritor.newLine();					

			// Crea un PrintWrite para poder usar print
			PrintWriter xPrintWriter = new PrintWriter(xEscritor);
			
			// Grabamos todo de Nuevo
			xPrintWriter.println("Tercera Línea");
            xPrintWriter.println(xInt);
            xPrintWriter.println(xChar);
            xPrintWriter.println(xFloat);
            xPrintWriter.println(xDouble);
             

			// Mensaje de Cierre
			System.out.println("Se ha finalizado de grabar");

			// Cierra el Print, Escritor y Archivo
			xPrintWriter.close();
			xEscritor.close();			
			xFile.close();
						
		}
		catch(java.io.IOException ioex) 
		{ 
			// Despliega el Error
			System.out.println(ioex.getMessage());			
		}
		
	}
}
