import java.util.Date;

public class c18_funciones {

    public static void main(String[] args) {
        
        // Clase 18. Funciones
        // Una Funcion es un conjunto de instrucciones a las cuales se les asigna un nombre; el nombre de
        // la funcion; y que realizan una funci�n espec�fica y devuelven un valor.
        // Las funciones al ser llamadas, debido a que devuelven un valor; pueden asignarse a una variable
        // la cual debe de ser del mismo tipo que la funcion.
        
        // Variable local al procedimiento main
        int iDiaSemana;
        String strDiaNombre;

        // Llama la funci�n que obtiene el d�a                
        iDiaSemana= fnintGetDiaSemana();
        
        // Ciclo que imprime tabla de multiplicar
        System.out.println("Dia de la Semana:"+iDiaSemana);            
                
        // Llama la funci�n que obtiene el nombre del d�a                
        strDiaNombre= fnStringGetDiaSemanaNombre();
        
        // Ciclo que imprime tabla de multiplicar
        System.out.println("Dia de la Semana Nombre:"+strDiaNombre);            
        
        
    }
    @SuppressWarnings("deprecation")
	public static int fnintGetDiaSemana(){
        
        // Variable para la fecha
        Date dateHoy = new Date();
        
        // Devuelve el d�a
        return dateHoy.getDay();
        
        
    }
    public static String fnStringGetDiaSemanaNombre(){
        
        // Variable para la fecha
        Date dateHoy = new Date();
        
        // Variable para el dia de la semana
        @SuppressWarnings("deprecation")
		int iDiaSemana = dateHoy.getDay();
     
        
        // Variable para el Nombre
        String strResult="";
        
        // Compara el d�a        
        switch(iDiaSemana) { // Agregar -15 en la expresi�n; y agregar 12.5 y ver que falla        
        case 1:
             strResult= "Lunes";
             break;
        case 2:
            strResult= "Martes";
            break;
        case 3:
            strResult= "Miercoles";
            break;
        case 4:
            strResult= "Jueves";
            break;
        case 5:
            strResult= "Viernes";
            break;
        case 6:
            strResult= "S�bado";
            break;
        case 7:
            strResult= "Domingo";
            break;        
        default:
            System.out.println("Error No esperado");    
            break;
        }
        
        // Devuelve el Nombre del d�a
        return strResult;
        
    }
}
