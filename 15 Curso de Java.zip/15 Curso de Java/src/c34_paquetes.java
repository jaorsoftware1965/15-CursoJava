import hola.*;

public class c34_paquetes {

	@SuppressWarnings("unused")
	public static void main(String[] args) 
	{
        // 
        // Clase 34 - Paquetes
        // www.jaorsoftware.cu.cc
		// 
		// Un paquete (package) es una librería de clases que se agrupan bajo
		// un mismo nombre para evitar problemas de nomenclatura o identificadores
		// repetidos.¿Que significa lo anterior?.
		
		// En un mismo paquete, no puede haber 2 clases que tengan el mismo nombre
		// pero si puede haber 2 clases con el mismo nombre pero en diferente paquete.
		
		// Los paquetes están organizados jerárquicamente y agrupan clases e interfaces 
		// que tienen un propósito común.

		// Las librerías de java, se encuentran almacenadas en paquetes para poder
		// utilizarlas.

		// Es posible poder utilizar Clases que se encuentren en un paquete determinado
		// utilizando la instrucción "import".
				
		// La siguiente sentencia "import graphics.Circle;" coloca a nuestra disposición
		// la Clase Circle del paquete graphics.
		
		// Esta sentencia debe estar al principio del fichero antes de cualquier definición 
		// de clase o de interface y hace que la clase o el interface esté disponible para 
		// su uso por las clases y los interfaces definidos en el fichero.
		
		// Si se quieren importar todas las clases e interfaces de un paquete, por ejemplo, 
		// el paquete graphics completo, se utiliza la sentencia import con el caracter 
		// comodín asterisco '*'; de la siguiente forma: import graphics.*;
		
		// Al definir una clase; podemos establecer a que paquete pertenecerá; utilizando
		// la palabra reservada "package" seguida del nombre del paquete. Ejemplo:
		
		// package BaseDatos;
		
		// Si se omite el nombre del paquete; se considera que la Clase pertenecerá al 
		// paquete "default".
		
		// El Nombre del Paquete: puede estar compuesto por varios identificadores separados 
		// por puntos. Por ejemplo:
		// BaseDatos.MySql
		// BaseDatos.Access
		
		// Unicamente las clases e interfaces declaradas como public podrán ser accedidas
		// desde otro paquete.
		
		// Pueden existir varios ficheros fuente (.java) con la misma declaración de paquete,
		// de forma que todas las clases e interfaces declaradas en ficheros con el mismo
		// nombre de paquete se incluirán en la misma librería (paquete).

		// Las clases e interfaces declaradas como miembros del paquete deberán estar en un
		// directorio con el mismo nombre que el del paquete para poder ser utilizadas por
		// otros paquetes, teniendo en cuenta que cada uno de los distintos identificadores
		// separados por puntos representa un directorio diferente. Así, las clases declaradas
		// en el paquete BaseDatos.MySql deberán estar almacenadas en el directorio 
		// BaseDatos\MySql.

		// Además, para hacer uso de estas clases, el directorio en el cual está el
		// subdirectorio BaseDatos tendrá que estar incluido en la variable CLASSPATH.
		
		// Creamos 2 Objetos usando Clases del Paquete Hola
        Hola      oHola      = new Hola();		
	    HolaMundo oHolaMundo = new HolaMundo();
    }

}
