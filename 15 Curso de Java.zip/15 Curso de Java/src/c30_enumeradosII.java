
enum DiasSemanaExtendido
{
 
	// Declaro los Enumerados con un Valor entre Paréntesis
    Domingo  ("Ir a Misa, a Comer y a Pasear",300),
    Lunes    ("Inicio de Semana",100),
    Martes   ("Ni te cases ni te embarques",200),
    Miercoles("Cine 2 x 1",350),
    Jueves   ("Ya casi terminamos",120),
    Viernes  ("Gracias a Dios es Viernes",200),
    Sabado   ("Descansando en Casa",150);   
 
    // Propiedad para la Descripción
    private String strDescripcion;
    
    // Propiedad para el Gasto
    private int intGastoDelDia;
 
    // Constructor
    DiasSemanaExtendido(String strActividad,int intGastos)
    {
 	    // Asigna la Descripción
        strDescripcion = strActividad;
        
        // Asigna el Gasto
        intGastoDelDia = intGastos;
    }
 
    // Método para Obtener la Descripción
    public String getDescripcion()
    {
 	   // Retorna la Descripcion
        return strDescripcion;
    }
    
    // Método para Obtener el Gasto
    public int getGasto()
    {
 	   // Retorna la Descripcion
        return intGastoDelDia;
    }
    
}

public class c30_enumeradosII {
	// Función Principal
    public static void main(String[] args) 
    {
    	
		/* 
        Curso de Programación con Java
        Clase 30. Enumerados II
        Derechos Reservados JaorSoftware 2015
        www.jaorsoftware.cu.cc
	    	    
        En JAVA es posible redefinir y extender la forma en que funciona un objeto
        Enumerado.
        
        Para hacerlo simplemente se define enum, como cualquier otra clase, en donde
        inicialmente, se deben de colocar los valores del Enumerado y seguido entre
        paréntesis; otros valores, separados por ",", los cuales indicarán la forma
        en que será definido el constructor de la Clase.
        
        Una vez hecho lo anterior, se deben de definir las propiedades correspondientes
        a los valores que se le han agregado al valor de los Enumerados.
        
        Finalmente se definen los métodos que se deseen utilizar para poder acceder 
        a las nuevas características del Enum
        
	    */    	
    	  
    	
        // Mensaje de la Clase
        System.out.println("Curso de Java");
        System.out.println("Clase 30 - Enumerados II\n");
     
        // Declarando una Variable
        DiasSemanaExtendido xDiaSemana;
        
        // Asignando Valores
        xDiaSemana = DiasSemanaExtendido.Miercoles;

        // Desplegando El Valor del Enumerado
        System.out.println("Desplegando el Valor del Enumerado");
        System.out.println("Dia:"+xDiaSemana);
        System.out.println("Dsc:"+xDiaSemana.getDescripcion());
        System.out.println("$$$:"+xDiaSemana.getGasto());
        System.out.println("");
        
        
        // Desplegando los elementos del Arreglo con for extendido
        System.out.println("Desplegando Información de los Valores del Enumerado");       
            	        
        // Desplegando los Valores del Enumerado Extendido
        for(DiasSemanaExtendido xDia : DiasSemanaExtendido.values()) 
        {
        	// Desplegamos la Información de Cada Valor
        	System.out.println("Dia Semana:"+xDia.toString() + "; Su Ordinal: " + xDia.ordinal());
        	System.out.println("Su Descripcion:" +xDia.getDescripcion());
        	System.out.println("El Gasto:" +xDia.getGasto());
        	System.out.println("");
        }

    }

}
