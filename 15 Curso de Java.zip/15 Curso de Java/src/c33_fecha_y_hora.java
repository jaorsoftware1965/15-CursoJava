import java.util.Calendar;


public class c33_fecha_y_hora {

	public static void main(String[] args) 
	{
        // Clase 33 - Fecha y Hora
		// 
		// El Manejo de la Fecha y la Hora es fundamental en cualquier
		// Sistema, ya que el llevar el registro de cuando suceden los
		// eventos es siempre importante saberlo.
		
		// Para manejar la Fecha y Hora, JAVA maneja diversas formas para
		// realizarlo; en este caso presentaremos el uso de la Clase
		// Calendar
		
		// La Clase Calendar nos permite tener control sobre el Día, Mes, Año,
		// Hora, Minutos y Segundos
		
		// Creamos una instancia del Calendario
		Calendar now = Calendar.getInstance();
		
		// Obtenemos en forma Separada la Información
		int iHora    = now.get(Calendar.HOUR_OF_DAY);
		int iMinuto  = now.get(Calendar.MINUTE);
		int iSegundo = now.get(Calendar.SECOND);
		int iMes     = now.get(Calendar.MONTH) + 1;
		int iDia     = now.get(Calendar.DAY_OF_MONTH);
		int iAnio    = now.get(Calendar.YEAR);
		
		// Desplegamos la Información.
		System.out.println("Fecha: "+iDia+"/"+iMes+"/"+iAnio);
		
		// Desplegamos la Hora.
		System.out.println("Hora: "+iHora+":"+iMinuto+":"+iSegundo);
				
		// Operaciones con la Fecha Agregamos 10 dias
		now.add(Calendar.DAY_OF_MONTH, 10);
		
		// Obtenemos en forma Separada la Información
		iHora = now.get(Calendar.HOUR_OF_DAY);
		iMinuto = now.get(Calendar.MINUTE);
		iSegundo = now.get(Calendar.SECOND);
		iMes = now.get(Calendar.MONTH) + 1;
		iDia = now.get(Calendar.DAY_OF_MONTH);
		iAnio = now.get(Calendar.YEAR);
		
		// Desplegamos la Información.
		System.out.println("Fecha: "+iDia+"/"+iMes+"/"+iAnio);
		
		// Operaciones con la Fecha Agregamos 10 dias
		now.add(Calendar.DAY_OF_MONTH, -20);
		now.add(Calendar.MONTH, 1);
		now.add(Calendar.YEAR, 1);
		now.add(Calendar.MINUTE, 10);
		now.add(Calendar.HOUR_OF_DAY, 10);
		
		// Obtenemos en forma Separada la Información
		iHora = now.get(Calendar.HOUR_OF_DAY);
		iMinuto = now.get(Calendar.MINUTE);
		iSegundo = now.get(Calendar.SECOND);
		iMes = now.get(Calendar.MONTH) + 1;
		iDia = now.get(Calendar.DAY_OF_MONTH);
		iAnio = now.get(Calendar.YEAR);
		
		// Desplegamos la Información.
		System.out.println("Fecha: "+iDia+"/"+iMes+"/"+iAnio);
		
		// Desplegamos la Hora.
		System.out.println("Hora: "+iHora+":"+iMinuto+":"+iSegundo);
				
		// Establecer La Fecha y Hora
		now.set(Calendar.DAY_OF_MONTH,14);
		now.set(Calendar.MONTH,9-1);
		now.set(Calendar.YEAR,2015);
		now.set(Calendar.HOUR_OF_DAY,10);
		now.set(Calendar.MINUTE,20);
		now.set(Calendar.SECOND,30);
		
		// Obtenemos en forma Separada la Información
		iHora = now.get(Calendar.HOUR_OF_DAY);
		iMinuto = now.get(Calendar.MINUTE);
		iSegundo = now.get(Calendar.SECOND);
		iMes = now.get(Calendar.MONTH) + 1;
		iDia = now.get(Calendar.DAY_OF_MONTH);
		iAnio = now.get(Calendar.YEAR);
		
		// Desplegamos la Información.
		System.out.println("Fecha: "+iDia+"/"+iMes+"/"+iAnio);

		// Desplegamos la Hora.
		System.out.println("Hora: "+iHora+":"+iMinuto+":"+iSegundo);

		// Podemos Limpiar la Fecha y Ver cuales son los valores Iniciales
		now.clear();

		// Obtenemos en forma Separada la Información
		iHora = now.get(Calendar.HOUR_OF_DAY);
		iMinuto = now.get(Calendar.MINUTE);
		iSegundo = now.get(Calendar.SECOND);
		iMes = now.get(Calendar.MONTH) + 1;
		iDia = now.get(Calendar.DAY_OF_MONTH);
		iAnio = now.get(Calendar.YEAR);
		
		// Desplegamos la Información.
		System.out.println("Fecha: "+iDia+"/"+iMes+"/"+iAnio);

		// Desplegamos la Hora.
		System.out.println("Hora: "+iHora+":"+iMinuto+":"+iSegundo);
		
    }
}