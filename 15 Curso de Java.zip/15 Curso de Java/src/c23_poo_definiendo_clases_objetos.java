

// Defino la Clase Persona
class classPersona {
        
    // Definimos las propiedades
    String strNombre;
    String strApellido;
    char   chrSexo;
    int    intEdad;
    char   chrEdoCivil;
    private String strDireccion;
    
    // Constructor de la Clase
    classPersona(){
    
        strNombre= "Juan";
        strApellido="P�rez";
        chrSexo ='H';
        intEdad=33;
        chrEdoCivil='S';
    }

    // Constructor de la Clase con Par�metros
    classPersona(String pNombre){
    
        strNombre= pNombre;
        strApellido="";
        chrSexo =32;
        intEdad=0;
        chrEdoCivil=32;
    }
    
    // Procedimiento para definir la Direcci�n
    void SbSetAddress(String pAddress){
        
        // Establece la direcci�n
        strDireccion = pAddress;
        
    }
    // M�todo que obtiene la direcci�n
    String  fnStrGetAddress(){
        
        // Retorna la Direcci�n
        return strDireccion;
    }
    
    // M�todo para Imprimir la Informaci�n
    void SbPrintPersonaInfo() {
        
        // Imprime la Informacion del Cliente        
        System.out.println("\n");
        System.out.println("Nombre:"+strNombre);
        System.out.println("Apellido:"+strApellido);
        if (chrSexo=='H')
           System.out.println("Sexo:Hombre");
        else
            if (chrSexo=='M')
               System.out.println("Sexo:Mujer");
            else
               System.out.println("Sexo:Falta indicar");
        System.out.println("Edad:"+intEdad);
        System.out.print("Estado Civil:");        
        switch (chrEdoCivil) {        
        case 'S':
            System.out.println("Soltero");
            break;
        case 'C':
            System.out.println("Casado");
            break;
        case 'V':
            System.out.println("Viudo");
            break;
        case 'U':
            System.out.println("Uni�n Libre");
            break;
        default:
            System.out.println("No Registrado");
        }
        
    }
    
}
public class c23_poo_definiendo_clases_objetos {
    public static void main(String[] args) {
        
        // Clase 23. Programaci�n Orientada a Objetos II
        // Temas: Definici�n de Clases
        // Para definir una clase haremos uso de la la palabra reservada class seguida del nombre que le colocaremos
        // a la clase,y despues como cualquier otra secci�n de c�digo; utilizaremos llaves de apertura y de cierre.
        // Dentro de estas llaves, definiremos las propiedades y m�todos de la clase
        // Ejemplo:
        // class NombreClase {
        //
        //   Definici�n de M�todos y Propiedades de la Clase
        //}
        // Como lo indicamos en la clase anterior, dentro de la clase podremos definir variables; las cuales ser�n
        // las propiedades de la clase; y tambi�n podremos definir funciones y propiedades; las cuales ser�n los
        // m�todos de la clase
        // A continuaci�n veremos como definir una clases y como definir objetos de ellos.        
               
        
        // Define un objeto de la clase Persona sin indicar el Nombre
        classPersona oPersona1 = new classPersona();
        oPersona1.strNombre="Benito";
        oPersona1.strApellido="Ju�rez";
        oPersona1.chrEdoCivil='C';
        oPersona1.chrSexo='H';
        oPersona1.intEdad=33;
        oPersona1.SbSetAddress("Domicilio Conocido");
        
        // Despliega la Informaci�n de la Persona
        oPersona1.SbPrintPersonaInfo();
        
        // Define un objeto de la clase Persona indicando el Nombre
        classPersona oPersona2 = new classPersona("Jose Luis");

        // Despliega la Informaci�n de la Persona
        oPersona2.SbPrintPersonaInfo();
        
        // Despliega solo la informaci�n de la Persona
        System.out.println("Direcci�n:"+oPersona1.fnStrGetAddress());
    
    }    
}
