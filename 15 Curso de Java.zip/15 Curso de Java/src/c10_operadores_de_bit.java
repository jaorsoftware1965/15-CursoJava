
public class c10_operadores_de_bit {

    public static void main(String[] args) {
        // Clase 10. Operadores III. Operadores de Bit
        // Los Operadores de Bit son aquellos que sirven para manipular números pero desde su representación binaria
        // Para entender esta clase es indispensable saber como se representa un número en binario
                        
        // Declaracion de variables numéricas
        int x=9; // Otra forma de declarar variables, todas las del mismo tipo en la misma línea.
        int y=0;
        @SuppressWarnings("unused")
		int z=0;

        // Aplicando el Complemento obtener el negativo del número
        x = ~x;
        x = ~x;
        
        
        // Aplicando operador Bit a Bit And(&)
        x = 10; // =  00001010
        y =  9; // =  00001001
        z = x & y;//  00001000 = 8
        
        // Aplicando operador Bit a Bit Or(|)
        z = x | y;//  00001011 = 11
        
        // Aplicando operador Bit a Bit Or Exclusivo 1 en únicamente una posición
        x = 42; // =  00101010
        y = 13; // =  00001101
        z = x ^ y;//  00100111 = 39
        
    
        // Aplicando desplazamiento a la izquierda
        // 42 =  00101010
        // 84 =  01010100
        z = x << 1;   
        // 168 = 10101000
        z = x << 2; 
        
        // Aplicando desplazamiento a la derecha
        // 42 =  00101010
        // 21 =  00010101
        z = x >> 1;
        // 10 =  00001010
        z = x >> 2;
        
        // Desplazamiento a la derecha sin signo
        x=-15;
        ///  101111111010010101101
        ///  10 1110111
        z = x >> 1;
        z=  x >>> 1;
    }
}
