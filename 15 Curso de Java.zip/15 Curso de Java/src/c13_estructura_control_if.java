
public class c13_estructura_control_if 
{
    public static void main(String[] args) 
    {
        
        // Clase 13. Estructuras de Control I
        // Temas. Bloque de Código y Sentencia if
        
        // Antes de comenzar a estudiar las Estructuras de Control de Flujo, estudiaremos primeramente un concepto
        // importante que es el "Bloque de Código" o "Sección de Código".
        
        // Un Bloque de código, es un conjunto de instrucciones los cuales se encuentran delimitados por "{}".
        // Si analizamos la función main, después de su declaración; se coloca un "{" de apertura, indicando con
        // esto el inicio del Bloque de Código, la cual finaliza con una "}" de cierre, indicando con esta la 
        // finalización de la función. De lo anterior, podemos definir la sintaxis de un bloque de código de
        // la siguiente forma:
        // { Bloque de Código } o
        
        // {
        //   Bloque de C�digo
        // }
        // donde Bloque de Código, es un conjunto o secuancia de instrucciones; cada una de ellas finalizada con ";".
        // Un Bloque de Código, puede consistir en una instrucción única y en este caso, no es necesario que esté
        // entre llaves. Las funciones o procedimientos, siempre deben de tener llaves de apertura y cierre.
        // La sentencia vacía consiste en un solo punto y coma (;) y no realiza proceso alguno.
        
        // La estructura de control por excelencia en todos los lenguajes de programación es la sentencia "if".
        // Esta sentencia permite evaluar una expresión que debe tener un resultado falso o verdadero; es decir
        // booleano; y dependiendo de estos 2 posibles resultado; el flujo del programa se dirige hacia un punto 
        // o hacia otro.
        
        // La sintaxis mas simple del uso de la sentencia if es:        
        // if (condición1)
        // {
        //     bloque de instrucciones si condicion1 es true
        // }
        // instrucciones que continuan al finalizar la sentencia if
        
        // Otra sintaxis mas simple del uso de la sentencia if es:        
        // if (condición1)
        // {
        //     bloque de instrucciones si condicion1 es true
        // }
        // else
        // {
        //     bloque de instrucciones si condicion1 es false
        // }
        // instrucciones que continuan al finalizar la sentencia if
        
        // Dentro los bloques de instrucciones, es posible incluir o ANIDAR, mas sentencias if
        // if (condición1)
        // {
        //     instrucciones si condición1 es true
        //     if (condicion11)              
        //     {
        //        instrucciones si condicion11 es true
        //        puede haber mas sentencias "if" en este bloque
        //     }
        //     else
        //     {
        //        instrucciones si condicion11 es false
        //        puede haber mas sentencias "if" en este bloque
        //     }
        // }
        // else
        // {
        //     if (condicion12)
        //     {
        //        instruciones si condicion12 es true
        //        puede haber mas sentencias "if" en este bloque
        //     }
        //     else
        //     {
        //        instrucciones si condicion12 es false
        //        puede haber mas sentencias "if" en este bloque
        //     }
        // }
        
        // Declaramos variables
        String  strNombreEmpleado = "Juan";
        
        @SuppressWarnings("unused")
		String  strApellidoEmpleado = "Perez";
        
        
        int     intEdad = 34;
        boolean bCasado = false;
        
        // Accion: si el Empleado se llama Juan  imprime Mensaje "Empleado encontrado"
        if (strNombreEmpleado=="Juan")
        {
            System.out.println("Empleado Encontrado");    
        }
        
        // Acción: si el Empleado se llama Juan  imprime Mensaje "Empleado encontrado" y que imprima su edad
        // sin importar si se llama Juan o No
        if (strNombreEmpleado=="Juan")
        {
            System.out.println("Empleado Encontrado");    
        }
        
        System.out.println("Edad:"+intEdad);    
        
        // Acción: si el Empleado se llama Juan  imprime Mensaje "Empleado encontrado" si no despliega su nombre
        if (strNombreEmpleado=="Juan"){
            System.out.println("Empleado Encontrado");    
        }
        else// Ejemplo de que no se necesitan llaves cuando es solo una instrucción
            System.out.println("Empleado No Encontrado");    
        
        // Acción: si el Empleado se llama Juan  
        //              a) imprime Mensaje "Empleado encontrado"
        //              b) Si es casado que imprima "Estado civil casado" y si no que imprima su edad
        //         si no se llama juan
        //              a) imprima su edad
        //              b) Si no es casado que imprima "Estado civil Soltero"
        if (strNombreEmpleado=="Juan"){
            System.out.println("Empleado Encontrado");    
            if (bCasado)
                System.out.println("Estado Civil Casado");    
            else  
                System.out.println("Edad:"+intEdad);    
        }
        else{            
            System.out.println("Edad:"+intEdad);    
            if (!bCasado){
                System.out.println("Estado Civil Soltero");    
            }
        }
        
        // Acción. Si el empleado se llama Beto entonces 
        //             Despliega mensaje de que no se llama Juan
        //             Si es casado despliega Apellido y Edad
        //         De otro modo (Si no se llama Beto) haz
        //             Despliega mensaje de que no se llama Beto
        //             Despliega edad
        //             Si no es casado despliega Mensaje de que es Soltero
        
        
        // Modifico el valor del Nombre
        strNombreEmpleado="Beto";
        bCasado=true;
        
        if (strNombreEmpleado=="Beto")
        {
        	System.out.println("No se llama Juan");
        	if (bCasado)
        	{
        		System.out.println("Apellido:"+strApellidoEmpleado);
        		System.out.println("Edad:"+intEdad);
        	}       
        }
        else
        {
        	System.out.println("No se llama Beto");
        	System.out.println("Edad:"+intEdad);
        	if (!bCasado)
        	{
        		System.out.println("Es Soltero");
        	}
        }
    }
}
