
public class c11_operadores_de_asignacion {
    public static void main(String[] args) {
        // Clase 11. Operadores IV. Operadoresde de Asignaci�n
        // El operador de asignaci�n visto hasta esta clase es "="; el cual hemos utilizado para simplemente
        // asignar valores a una variable.
        // Existen otros operadores que al momento de asignar un valor, realizan una operaci�n, la cual puede
        // ser matem�tica, l�gica o de asignaci�n.
        // A continuaci�n se muestra el uso de cada una de ellas.
        
                        
        // Declaracion de variables num�ricas
        int x=9; 
        int y=10;
        
        // Aplicando el Complemento obtener el negativo del n�mero
        x++;   // x = x+1;  Incrementa en 1 a la variable despues de usarla en la instrucci�n
        x--;   // x = x-1;  Decrementa en 1 a la variable despues de usarla en la instrucci�n
        ++x;   // x = x+1;  Incrementa en 1 a la variable antes de usarla en la instrucci�n
        --x;   // x = x-1;  Decrementa en 1 a la variable antes de usarla en la instrucci�n
        
        // Ejemplo
        x=5;
        System.out.println(x++);
        System.out.println(x);
        x=5;
        System.out.println(++x);
        System.out.println(x);
        
        // Operaciones aritm�ticas al asignar
        x+=y;  // x = x + y;
        x-=y;  // x = x - y;
        x*=2;  // x = x * 2;
        y/=2;  // x = x / 2;
        x%=2;  // x = x % 2;
        
        // Asigno valores de nuevo
        x=10; 
        y=8;
        
        // Operaciones de bit
        x|=y;  // x = x | y;
        x&=y;  // x = x & y;
        x^=y;  // x = x ^ y;
        x<<=1; // x = x << 1;
        y>>=1; // y = y >> 1;
        x>>>=1;// x = x >>> 1;
    }
}
