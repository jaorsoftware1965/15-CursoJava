
public class c28_foreach {

	// Función main de la Clase
    public static void main(String[] args) 
    {
        
        /* 
        
        Curso de Programación con Java
        Clase 28. Ciclo for Extendido (for each)
        Derechos Reservados JaorSoftware 2015
        www.jaorsoftware.cu.cc
        
        En las últimas versiones de Java se introdujo una nueva forma de uso del for, 
        a la que se denomina “for extendido” o “for each”. 
        
        Esta forma de uso del for, facilita el recorrido de objetos existentes en una 
        colección de datos sin necesidad de definir el número de elementos a recorrer
        y sin necesidad de usar un índice para ubicar la posición del elemento. 
        
        La sintaxis que se emplea es la siguiente:
        
        for ( TipoDato Variable : ColeccionDatos) 
        {

           Instrucciones....

        }
        
        donde:
        
        TipoDato. Es el tipo de dato correspondiente a la Colección de datos que se
        va a recorrer. Si se tratara de un arreglo de enteros; entonces el tipo de
        dato debe ser entero.
        
        Variable. Es la variable que va a tomar uno a uno los valores de la colección
        de Datos.
        
        ColeccionDatos. Es el arreglo u objeto que contiene la colección de datos.
        
        Como podemos observar, la sintaxis es distinta a la ya estudiada. No hace
        referencia a índice alguno a través de alguna variable de conteo, y no se
        identifica un tope.      
    	
    	*/
    	
    	 // Arreglo de Enteros
        int[] intArrCalificaciones = new int[10];
        
        // Coloco las 10 calificaciones
        intArrCalificaciones[0]=97;
        intArrCalificaciones[1]=69;
        intArrCalificaciones[2]=77;
        intArrCalificaciones[3]=89;
        intArrCalificaciones[4]=88;
        intArrCalificaciones[5]=78;
        intArrCalificaciones[6]=90;
        intArrCalificaciones[7]=68;
        intArrCalificaciones[8]=90;
        intArrCalificaciones[9]=80;
        
        // Mensaje de la Clase
        System.out.println("Curso de Java");
        System.out.println("Clase 28 - Ciclo for extendido (for each)\n");
        
        // Desplegando los elementos del Arreglo con for extendido
        System.out.println("Desplegando los Elementos del Arreglo de Int con for extendido");
        
        // Defino el Ciclo for extendido
        for (int xCalificacion : intArrCalificaciones)
        {
           	// Imprimo el Valor Actual
        	System.out.print(xCalificacion+" ");
        }
        
        
        // Arreglo para almacenar Nombre
        String[] StrArrNombres = new String[10];
        StrArrNombres[0]="José";
        StrArrNombres[1]="María";
        StrArrNombres[2]="Alba";
        StrArrNombres[3]="Daniel";
        StrArrNombres[4]="Manolo";
        StrArrNombres[5]="Miguel";
        StrArrNombres[6]="Gloria";
        StrArrNombres[7]="Carmen";
        StrArrNombres[8]="Lourdes";
        StrArrNombres[9]="Jaqueline";
        
        // Deja un Espacio
        System.out.println("\n");
        
        // Desplegando los elementos del Arreglo con for extendido
        System.out.println("Desplegando los Elementos del Arreglo de String con for extendido");
        
        // Defino el Ciclo for extendido
        for (String xNombre : StrArrNombres)
        {
           	// Imprimo el Valor Actua
        	System.out.print(xNombre+" ");
        }    	
        
        // Variable String       
        String StringVariable="JaorSoftware";
        
        // Deja un Renglón
        System.out.println("\n");
        
        // Desplegando los elementos del Arreglo con for extendido
        System.out.println("Desplegando los Caracteres de un String con for extendido");
        
        // Defino el Ciclo for extendido
        for (char xLetra : StringVariable.toCharArray())
        {
           	// Imprimo el Valor Actua
        	System.out.print(xLetra+" ");
        }    	       
    }	
}
