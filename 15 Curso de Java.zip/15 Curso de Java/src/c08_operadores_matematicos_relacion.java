
public class c08_operadores_matematicos_relacion {
    @SuppressWarnings("unused")
	public static void main(String[] args) {
        // Clase 08. Operadores. Operadores Matem�ticos y Operadores relacionales
        // Un operador es un s�mbolo o un grupo de s�mbolos para indicar operaciones entre variables u
        // objetos que almacenan informaci�n.
        
        // Los operadores matematicos que maneja Java, son los tradicionales que se utilizan en la vida 
        // cotidiana: +(suma), (resta), (multiplicacion), /(divisi�n) y % (m�dulo o residuo). Este �ltimo 
        // no es com�n pero es muy utilizado en programacion.
        // Los operadores matematicos son utilizados para realizar operaciones entre variables num�ricas y el
        // resultado que devuelven es un valor num�rico.
        
        // Los operadores relacionales tambi�n son los que se conocen comunmente en las matem�ticas tradicionales
        // y que son: > (mayor que), >=(mayor o igual que), <(menor que), <=(menor o igual que) !=(diferente)
        // y == (igual)        
        // Los operadores relacionales a diferencia de los operadores num�ricos, devuelven un valor booleano,
        // true o false.
        
        
        // Declaracion de variables num�ricas
        float fPrecio= 34.50f;
        float fIva=.15f;
        float fResultado =0;
        int iCantidad=24;
        int iResiduo;
        int x = 10;
        int y = 9;
        boolean bResultado;
        
        // Calcula el Resultado
        fResultado = fPrecio * (1+fIva);
        System.out.println("El resultado:"+fResultado);                  
        
        // Obtiene el precio en base al resultado y al iva
        fPrecio = 0;
        fPrecio = fResultado / (1+fIva);
        System.out.println("El Precio:"+fPrecio);                  
        
        // Obtiene el precio en base al resultado y al iva
        iCantidad = iCantidad - 5;
        iResiduo = iCantidad % 3;
        System.out.println("El Residuo:"+iResiduo);                  
        iResiduo = iCantidad / 3;
        System.out.println("El Cociente:"+iResiduo);                  
        
        // Ejemplos de Operadores Relacionales
        System.out.println(x < y);
        System.out.println(x <= y);
        System.out.println(x > y);
        System.out.println(x >= y);
        System.out.println(x != y);
        System.out.println(x == y);
        System.out.println(x == 10);
        System.out.println(x != 10);
        System.out.println(x != 9);
        System.out.println(x == 9);       
    }
}
