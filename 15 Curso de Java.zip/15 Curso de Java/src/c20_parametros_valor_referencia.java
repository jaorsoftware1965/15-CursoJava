import java.util.Date;
public class c20_parametros_valor_referencia {

    @SuppressWarnings("deprecation")
	public static void main(String[] args) {
        
        // Clase 20. Par�metros por Valor y por Referencia
        // Un parametro por valor es cuando la funci�n o procedimiento recibe una "copia" del dato, y aunque realice
        // modificacines a este; el dato original queda intacto.
        // Un par�metro por referencia es cuando una funci�n o procedimiento recibe el dato original, y si lo modifica
        // dentro de su c�digo, modificar� el dato original.
        // En JAVA existen pol�micas al respecto; y se indica que JAVA solo manejo par�emtros por referencia; y en esta
        // clase no entraremos en pol�mica al respecto; pero demostraremos el uso de ambos casos.
        
        // Variable int
        int iNumero=10;
        
        // Llama a la funci�n con el parametro
        System.out.println("El Cuadrado:"+fnIntCuadradoNumero(iNumero));            
        System.out.println("Verifica Modificaci�n:"+iNumero);            
        
        // Variable Integer
        Integer iNumero2=10;
        
        // Llama a la funci�n con el parametro
        System.out.println("El Cubo:"+fnIntCuboNumero(iNumero2));            
        System.out.println("Verifica Modificaci�n:"+iNumero2);            
        
        // Variable String
        String strMensajeOriginal="Hola Mundo";                
        
        // Ciclo que imprime tabla de multiplicar
        SbDespliegaMensaje(strMensajeOriginal);            
        
        // Ciclo que imprime tabla de multiplicar
        System.out.println("VErifica Modificaci�n"+strMensajeOriginal);            
        
        // Vector
        int[] intArrCalificaciones = {12,23,45,34,56,78,55,66,77,88};
        
        // Llama a la funci�n
        System.out.println("La Suma:"+FnIntSumaVector(intArrCalificaciones));                  
        
        // Verifica que si modific� el vector
        System.out.println("La Suma de Nuevo:"+FnIntSumaVector(intArrCalificaciones));            
        
        // Simula String con Vector
        String[] strArrMensaje = new String[1];
        
        // Asigna el Mensaje
        strArrMensaje[0]="Hola Mundo";        
        
        // Lo despleiga
        SbDespliegaMensajeArr(strArrMensaje);        
        
        // Veriica modificaci�n
        System.out.println("Verifica modificaci�n:"+strArrMensaje[0]);            
        
        // Asigna el Mensaje
        strArrMensaje[0]="Hola Mundo";        
        
        // Despliega el Mensaje
        SbDespliegaMensaje(strArrMensaje[0]);            
        
        // Verifico que no lo modifica
        System.out.println(strArrMensaje[0]);            
                
        // Objeto Fecha
        Date dateHoy = new Date();        
        
        // Un objeto como par�metro
        SbFecha(dateHoy);        
        
        // Imprime el Mes
        System.out.println(dateHoy.getMonth());            
                
    }
    private static int fnIntCuadradoNumero(int iNum){
        
        int iCuadrado = iNum * iNum;
        iNum = 0;
        return iCuadrado;
    }
    private static Integer fnIntCuboNumero(Integer iNum){
        
        Integer iCubo = iNum * iNum * iNum;
        iNum = 0;
        return iCubo;
    }
    private static void SbDespliegaMensaje(String vStrMensaje){
        
        // Ciclo que imprime tabla de multiplicar
        System.out.println(vStrMensaje);            
        
        // Modifica el valor de la variable
        vStrMensaje = "Enviado";
        
        // Ciclo que imprime tabla de multiplicar
        System.out.println(vStrMensaje);            
        
    }
    private static int FnIntSumaVector(int[] Vector){
        
        // Variable para sumar el vector
        int iSuma=0;
        
        // Variable para contar los elementos
        int iCta;
        
        // Ciclo para sumar los elementos
        for  (iCta=0; iCta<Vector.length; iCta++) {
            
            // Suma el elemento
            iSuma += Vector[iCta];
            Vector[iCta]=0;
            
        }
        
        // Devuelve la SUma
        return iSuma;
        
    }
    
    private static void SbDespliegaMensajeArr(String[] arrMensaje){
        
        // Ciclo que imprime tabla de multiplicar
        System.out.println(arrMensaje[0]);            
        
        // Modifica el Mensaje
        arrMensaje[0]="Modificado";
        
    }
    
    @SuppressWarnings("deprecation")
	private static void SbFecha(Date xFecha){
        
        // Ciclo que imprime tabla de multiplicar
        System.out.println(xFecha.getMonth());            
        
        // Modifica el Mes
        xFecha.setMonth(9);
        
        // Verifica que la haya modificado
        System.out.println(xFecha.getMonth());            
        
    }
}
