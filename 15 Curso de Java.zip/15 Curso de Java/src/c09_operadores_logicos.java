
public class c09_operadores_logicos {
    @SuppressWarnings("unused")
	public static void main(String[] args) {
        // Clase 09. Operadores II. Operadores Lógicos
        // Los Operadores Lógicos son aquellos que sirven para evaluar operandos booleanos; es decir
        // valores TRUE o FALSE; muy utilizados en las condiciones de instrucciones de control de Flujo
        // del Programa. 
        // Los operadores lógicos por excelencia son: AND (y), OR (o) y NOT(!). Son utilizados para evaluar
        // diversos valores o condiciones BOOLEANOS.
        // Existen en Matemáticas Booleanas o álgebra de Bool, unas tablas llamadas de verdad, para
        // representar los posibles valores para cada uno de estos operadores.
        
        // Tabla de Verdad AND . Solo devuelve TRUE(1) cuando los 2 operandos son TRUE(1)
        // Operando 1 		Operando 2 =  AND (&&)
        // -------------------------------------------
        //  True (1)  		True (1)  = 	True (1)
        //  True (1)  		False(0)  = 	False(0) 
        //  False(0)  		True (1)  = 	False(0)
        //  False(0)  		False(0)  = 	False(0)
        
        // Tabla de Verdad OR . Solo devuelve FALSE(0) cuando los 2 operandos son FALSE(0)
        // Operando 1 Operando 2 =  OR(||)
        // -------------------------------------------
        //  True (1)  		True (1)  = 	True (1)
        //  True (1)  		False(0)  = 	True (1) 
        //  False(0)  		True (1)  = 	True (1)
        //  False(0)  		False(0)  = 	False(0)        
        
        // Tabla de Verdad NOT(!) . Invierte el valor
        // Operando =  NOT(!)
        // -------------------------------
        // True (1) 	=  	False(0)  
        // False(0) 	=  	True (1)  
                
        // Declaracion de variables numéricas
        int x = 10,y = 9; // Otra forma de declarar variables, todas las del mismo tipo en la misma línea.
        boolean bResultado;
        
        // Ejemplos de AND
        bResultado = x > 10 && x > 8;
        bResultado = x > 10 && x > y;
        bResultado = x > 10 && x > 8 && x < 20;
        
        // Ejemplos de OR
        bResultado = x < 9  || x > 9;
        bResultado = x < 9  || x > 9 || x < 10;
        bResultado = x < 9  || x > 19 || x < 5;
        
        // Ejemplos de NOT
        bResultado = !(x < 9);
        bResultado = !(x < 9  || x > 9);
        bResultado = !(x < 9  || x > 9) || x < 10;
        bResultado = !(x < 9  || x > 19 || x < 5);
        
        // Ejemplos Combinados
        bResultado = false || false && true;
        bResultado = !false || true && false;
        bResultado = !false || !true && !false;
        bResultado = !true && !true && !false;
        bResultado = true && (false || true) && true;
        bResultado = true && false || false && true;
    }
}
