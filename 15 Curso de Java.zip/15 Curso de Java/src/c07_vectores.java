// Importamos la librer�a para manejar la clase Vector
import java.util.Vector;
import java.util.Date;


public class c07_vectores {

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void main(String[] args) {
        // Clase 07. Vectores
        // En las 2 clases anteriores vimos como manejar arreglos y matrices; los
		// cuales son de una longitud fija; es decir; que al definirlos; indicamos
		// cuantos elementos son los que se van a manejar.
		// En JAVA existe una clase llamada Vector; la cual nos permite manejar
		// arreglos, sin tener que definir un n�mero de elementos determinado
		// y en el cual se pueden agregar y eliminar elementos en forma din�mica.
		        
        // Vector para manejar Datos
		// Tarea ver como Inicializar Capacidad e Incremento
        Vector vecDatos =  new Vector();
        Integer xInteger = 34;
        
        // Verificamos el n�mero de Elementos
        System.out.println("Elementos del Vector al Inicializar:"+vecDatos.size());
        System.out.println("Capacidad del Vector al Inicializar:"+vecDatos.capacity());
        System.out.println("");
        
        // Agregamos elementos al Vector
        vecDatos.add("Juan");
        vecDatos.add("Jos�");
        vecDatos.add("Mar�a");
        vecDatos.add("Abraham");
        vecDatos.add("Issac");
        vecDatos.add("Moises");
        vecDatos.add(xInteger);
        vecDatos.add(43);
        vecDatos.add(45);
        vecDatos.add(78);
        vecDatos.add(12);
        vecDatos.add(new Date());
        vecDatos.add("Jos�");
        vecDatos.add("Mar�a");
        
        // Verificamos el n�mero de Elementos
        System.out.println("Elementos del Vector:"+vecDatos.size());
        System.out.println("Capacidad del Vector:"+vecDatos.capacity());
        System.out.println("");
        
        // Despliega el Vector por Objetos
        SbDespliegaVector(vecDatos);
        
        // Despliega el Vector por posici�n
        SbDespliegaVector2(vecDatos);                          
        
        // Buscando un dato en el Vector        
        System.out.println("Existe Mar�a en el Vector:"+vecDatos.contains("Mar�a"));
        System.out.println("Existe Ulises en el Vector:"+vecDatos.contains("Ulises"));
        System.out.println("");
        
        // Buscando por Posiciones
        System.out.println("Posici�n de Mar�a en el Vector:"+vecDatos.indexOf("Mar�a"));
        System.out.println("Posici�n de Ulises en el Vector:"+vecDatos.indexOf("Ulises"));
        System.out.println("");
        
        
        // Buscando por �ltimas Posiciones
        System.out.println("�ltima Posici�n de Mar�a en el Vector:"+vecDatos.lastIndexOf("Mar�a"));
        System.out.println("�ltima Posici�n de Ulises en el Vector:"+vecDatos.lastIndexOf("Ulises"));
        System.out.println("�ltima Posici�n de Jos� en el Vector:"+vecDatos.lastIndexOf("Jos�"));
        System.out.println("");
        
        // Modificando valores
        vecDatos.set(10, "DIEZ");
   
        // Despliega el Vector por posici�n
        SbDespliegaVector2(vecDatos);                          
        
        // Eliminando Elementos por posici�n
        vecDatos.remove(10);
        vecDatos.removeElementAt(10);

        // Despliega el Vector por posici�n
        SbDespliegaVector2(vecDatos);                          
        
        // Eliminando Elementos por Objeto
        vecDatos.remove("Moises");
        vecDatos.remove(xInteger);
        
        
        // Despliega el Vector por posici�n
        SbDespliegaVector2(vecDatos);                          
        
    }
	static void SbDespliegaVector(@SuppressWarnings("rawtypes") Vector xVector)
	{
		// Despliega mensaje de tipo de despliegue
		System.out.println("Desplegando Vector por Objetos");
		
		// Ciclo for usando objetos
		for (Object xObject : xVector) {
            System.out.println(xObject.toString());
        }
		System.out.println("");
	}
	@SuppressWarnings("rawtypes")
	static void SbDespliegaVector2(Vector xVector)
	{
		// Despliega mensaje de tipo de despliegue
		System.out.println("Desplegando Vector por Posici�n");
		// Ciclo por �ndice
		for (int intIndice=0; intIndice < xVector.size();intIndice++) {
			// Accede al objeto por indice
            System.out.println(xVector.get(intIndice));
            // Identico a usar
            //System.out.println(xVector.elementAt(intIndice));
        }
		System.out.println("");
	}
}
