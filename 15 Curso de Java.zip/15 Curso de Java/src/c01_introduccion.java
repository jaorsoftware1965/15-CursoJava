
public class c01_introduccion {

    public static void main(String[] args) {
        // Clase 01 - Introducción
        // La extensión de un archivo con código Java debe ser ".java"
        // Dentro del código de este archivo debe existir la definición de una clase que debe 
    	// llamarse de la misma forma que el nombre del archivo .java; es decir. 
    	// Si el archivo se llama: "juego.java"; debe existir una clase
        // dentro del código de este archivo que se llame "juego"
        // La función main es la que debe existir en la clase, ya que a partir de ahí 
    	// se ejecuta la aplicación.

     
        // Imprime el Mensaje a Out
        System.out.println("Bienvenidos al curso de Java");
    }
}
