import java.util.Date;
class Alumnos {
       int Edad;
}
public class c22_poo_clase_objeto {
    @SuppressWarnings({ "unused", "static-access" })
	public static void main(String[] args) {
        
        // Clase 22. Programaci�n Orientada a Objetos
        // Temas: Clases y Objetos.
        // La Programaci�n Orientada a Objetos es la parte medular de cualquier lenguaje de programaci�n en la 
        // actualidad. Todo son clases y objetos. Si observamos, al crear esta aplicaci�n, la funci�n maun es
        // parte de una clase; en este caso de la clase "poo".
        // La Programaci�n Orientada a Objetos; si lo vemos desde este punto de vista; es una forma avanzada de
        // declarar variables, funciones y procedimientos. Toda esta informaci�n se encuentra almacenada y relacionada
        // dentro de un mismo nombre y se puede hacer referencia a ello.
        // Los 2 conceptos mas importantes y fundamentales en la programaci�n orientada a objetos son las clases y
        // los objetos.
        // Una CLASE es una forma avanzada de definir variables las cuales se les llama PROPIEDADES, y de funciones y 
        // procedimientos; los cuales ahora les llamaremos m�todos; agrupados todos bajo un mismo nombre.
        // Un OBJETO es una instancia que se debe declarar de un tipo de CLASE.
        // Si hici�ramos una analog�a SIMPLE, pudieramos decir que una CLASE es como un TIPO DE DATO; solo que mas
        // avanzado, ya que no solo reserva memoria para almacenar informaci�n; sino que tambien reserva funciones y
        // procedimientos. 
        // De igual forma, un OBJETO es como una VARIABLE; el cual tenemos que indicar de que CLASE es para poder
        // utilizarlo.
        // Para declarar un OBJETO de una CLASE, se sigue la siguiente sintaxis:
        // CLASE objeto;
        // Ejemplos:
        String  strNombre;
        String  strApellido;
        
        // Si observamos, la forma de declarar un OBJETO de una CLASE, es similar a declarar una variable de un tipo de
        // dato.
        // Ahora. Una vez que hemos declarado un OBJETO de una CLASE; debemos de INSTANCIARLO para poder utilizarlo; lo        
        // cual no realizamos con las variables.
        // Para instanciar un OBJETO de una CLASE, debemos de utilizar el operador new, de la siguiente forma:
        // objeto = new CLASE();
        // Ejemplo
        strNombre = new String();
        
        // El operador new ejecuta(si existe) un m�todo de la CLASE, llamado CONSTRUCTOR; el cual veremos en la siguiente 
        // clase.
        // Una vez que ya tenemos el ohjeto instanciado, ya podemos hacer uso de sus propiedades y m�todos.(Para la
        // clase String de JAVA; no es necesario instanciarla; y con la CLASE Integer; no permite instanciarla
                                
        // Sin instanciar y con instanciar es posible usar un objeto de la Clase String
        strNombre= "Juan"; // Esto con la clase String de JAVA si es posible
        strApellido = "P�rez";
        
        // Con la clase Integer es posible tambien usar un objeto sin instanciar y es posible instanciar
        // pero con par�metros en la instanciaci�n.
        Integer intEdad;        
        intEdad = new Integer(5); //Esto lo permite con par�metros
        
        // Una vez que ya tenemos el objeto de la Clase espec�fica, podemos comenzar a utilizar las propiedades y 
        // m�todos que se encuentran definidos en la clase. Para acceder a ellos hacemos uso del operador ".".
        // Ejemplos:
        
        // Pasamos a may�sculas
        strNombre = strNombre.toLowerCase();
        
        // Obtien eel valor inte
        intEdad = intEdad.reverse(8);
        intEdad = intEdad.reverse(268435456);        
        
        // Es posible declarar un objeto e instanciarlo en una misma instrcucci�n.
        Date dFechaHoy = new Date();
        
        // Veamos otras clases
        // Caracter
        Character xChar = new Character('o');
        Character xChar2 = new Character('x');
        xChar2 = xChar.charValue();
        
        // Float
        Float xFloat = new Float(23.45);
        intEdad=xFloat.intValue();
        
        Alumnos oAlumno=new Alumnos();
        oAlumno.Edad=10;
        
    }    

}
