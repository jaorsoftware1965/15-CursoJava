import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;


public class c39_archivos_acceso_aleatorio_lectura {
	// -------------------------------------------------
	// Clase 39 - Archivos de Acceso Aleatorio Lectura
	// Autor - JAOR
	// www.jaorsoftware.cu.cc
	// -------------------------------------------------
	
    // En esta clase veremos como leer de Forma Aleatoria un archivo
	// realizandolo desde diversas partes.

	// Veremos como desplazarnos una cantidad específica de bytes, y
	// como verificar si un registro se encuentra marcado como activo
	// o como borrado.
	
	// Veremos tambien como leer una línea completa o leer tan solo
	// un caracter.
	
	// Función Principal
	public static void main( String args[] ) 
	{
		
		// Declaramos un Objeto de la Clase
        RandomAccessFile xFileAleatorio;
        
        // Variable para leer del Archivo
        String strLinea;
        char cActivo;
        int iLongitud=23;              // 23 Longitud del Registro
        int iRegistro;

        // Captura de Excepciones 
        try 
        {
        	        	
        	// Leemos el Archivo de Acceso Directo
        	xFileAleatorio = new RandomAccessFile( "Datos.txt","r" );
            
        	// Desplegamos su longitud
        	System.out.println("Longitud del Archivo:"+xFileAleatorio.length());
        	System.out.println("Registros del Archivo:"+xFileAleatorio.length()/23);
        	
        	
        	// Nos movemos al principio del Archivo
        	xFileAleatorio.seek(0);
        	
		    // Leemos una Linea     
            strLinea=xFileAleatorio.readLine();
            
            // Mensaje
            System.out.println("Se ha leido el Registro Inicial:");
            System.out.println(strLinea);
            
            // Nos movemos a un registro específico y Modificamos el Registro
        	iRegistro=3;        	
        	xFileAleatorio.seek((iRegistro-1)*iLongitud);

		    // Leemos una Linea     
            strLinea=xFileAleatorio.readLine();
            
            // Mensaje
            System.out.println("Se ha leido el registro 3:");
            System.out.println(strLinea);

            // Nos movemos a un registro específico
        	iRegistro=4;        	
        	xFileAleatorio.seek((iRegistro-1)*iLongitud);
        	
        	// Nos desplazamos al caracter de Activo
            xFileAleatorio.skipBytes(21);
            
        	// Leemos el Caracter       	
            cActivo=(char) xFileAleatorio.read();
            
            // Lo Imprimimos.
            System.out.println("Marca:"+cActivo);
            
            // Verificamos si está activo
            if (cActivo=='*')
                // Desplegamos Caracter de Activo
                System.out.println("El Registro  está Borrado");
            else
            	// Desplegamos Caracter de Activo
                System.out.println("El Registro está Activo:");	                      
                        
            // Cerramos el fichero
            xFileAleatorio.close();
            
		} 
        catch (FileNotFoundException e) 
        {
        	System.out.println("Ocurrió un Error de Not File");
			e.printStackTrace();
		}
        catch (IOException e) 
        {
        	System.out.println("Ocurrió un Error Exception");
    		
			e.printStackTrace();
		}
        
    }
}