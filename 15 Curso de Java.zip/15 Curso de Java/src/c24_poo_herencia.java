import java.util.Date;

// Defino la Clase Persona
class classPersona2 {
        
    // Definimos las propiedades
    String strNombre;
    String strApellido;
    char   chrSexo;
    int    intEdad;
    char   chrEdoCivil;
    private String strDireccion;
    
    // Constructor de la Clase
    classPersona2(){
    
        strNombre= "Juan";
        strApellido="Pérez";
        chrSexo ='H';
        intEdad=33;
        chrEdoCivil='S';
    }

    // Constructor de la Clase con Parámetros
    classPersona2(String pNombre){
    
        strNombre= pNombre;
        strApellido="";
        chrSexo =32;
        intEdad=0;
        chrEdoCivil=32;
    }
    
    // Procedimiento para definir la Dirección
    void SbSetAddress(String pAddress){
        
        // Establece la dirección
        strDireccion = pAddress;
        
    }
    // Método que obtiene la dirección
    String  fnStrGetAddress(){
        
        // Retorna la Dirección
        return strDireccion;
    }
    
    // Método para Imprimir la Información
    void SbPrintPersonaInfo() {
        
        // Imprime la Informacion del Cliente        
        System.out.println("\n");
        System.out.println("Nombre:"+strNombre);
        System.out.println("Apellido:"+strApellido);
        if (chrSexo=='H')
           System.out.println("Sexo:Hombre");
        else
            if (chrSexo=='M')
               System.out.println("Sexo:Mujer");
            else
               System.out.println("Sexo:Falta indicar");
        System.out.println("Edad:"+intEdad);
        System.out.print("Estado Civil:");        
        switch (chrEdoCivil) {        
        case 'S':
            System.out.println("Soltero");
            break;
        case 'C':
            System.out.println("Casado");
            break;
        case 'V':
            System.out.println("Viudo");
            break;
        case 'U':
            System.out.println("Unión Libre");
            break;
        default:
            System.out.println("No Registrado");
        }
        
    }
    
}
class classEmpleado extends classPersona2 {
    
    // Definimos las propiedades
    private float  fSueldo;
    @SuppressWarnings("unused")
	private Date   dIngreso = new Date();
    String sDepartamento;
    
    
    // Constructor de la Clase
    classEmpleado(float pSueldo, Date pIngreso, String pDepartamento){
    
        // Asigna Sueldo, Fecha de Ingreso y Departamento
        fSueldo = pSueldo;
        dIngreso = pIngreso;
        sDepartamento = pDepartamento;        
        
    }
    // Constructor de la Clase
    classEmpleado(String pNombre,float pSueldo, Date pIngreso, String pDepartamento){
    
        // Asigna Sueldo, Fecha de Ingreso y Departamento
        super(pNombre);
        fSueldo = pSueldo;
        dIngreso = pIngreso;
        sDepartamento = pDepartamento;        
        
    }
    // Procedimiento para definir la Direcci�n
    void SbSetSueldo(float pSueldo){
        
        // Establece la direcci�n
        fSueldo = pSueldo;
        
    }
    // M�todo que obtiene la direcci�n
    float  fnfloatGetSueldo(){
        
        // Retorna la Direcci�n
        return fSueldo;
    }
    
}

public class c24_poo_herencia {

    public static void main(String[] args) {
        
        // Clase 24. Programación Orientada a Objetos III
        // Temas: Herencia
        // Uno de los aspectos mas importantes en la programación Orientada a Objetos, es la Herencia.
        // La Herencia en POO es la caracteristica de poder definir una clase y al hacerlo indicarle 
    	// que HEREDA las características de otra ya existente.
        // Esto viene a resolver el problema de redundancia de código y a permitir tener una programación 
    	// mas ágil y mas estructurada.
        // Para definir una clase y heredar características de otra, utilizamos la palabra reservada 
    	// extends utilizando la siguiente sintanxis:
        
        // class nueva_clase extends clase_padre
        
        // En la sintaxis anterior, definimos una "nueva_clase" e indicamos que esta heredar� de las caracter�sticas
        // de la "clase_padre".
        
        // Ejemplo:
        Date fHoy = new Date();
        classEmpleado oEmpleado = new classEmpleado(5800,fHoy,"Informatica");
        
        // Observamos como podemos usar lo definido en la clase persona
        oEmpleado.strNombre="Benito";
        oEmpleado.strApellido="Juárez";
        oEmpleado.chrEdoCivil='C';
        oEmpleado.chrSexo='H';
        oEmpleado.intEdad=33;
        oEmpleado.SbSetAddress("Domicilio Conocido");
        
        // Despliega la Informaci�n de la Persona
        oEmpleado.SbPrintPersonaInfo();
        
        // Imprimo el Sueldo
        System.out.println("Dirección:"+oEmpleado.fnfloatGetSueldo());
        
        
        // Define un objeto de la clase Persona indicando el Nombre
        classEmpleado oEmpleado2 = new classEmpleado("Jose Luis",5700,fHoy,"Contabilidad");

        // Despliega la Información de la Persona
        oEmpleado2.SbPrintPersonaInfo();
        
        // Despliega solo la informaci�n de la Persona
        System.out.println("Sueldo:"+oEmpleado.fnStrGetAddress());
        
        // Establezco el Sueldo
        oEmpleado2.SbSetSueldo(8700);
        
        // Imprimo el Sueldo
        System.out.println("Sueldo:"+oEmpleado2.fnfloatGetSueldo());                        
        
    }

}
