
public class c21_parametros_main {
    public static void main(String[] args) {
        
        // Clase 21. Par�metros para la funci�n main
        // Hemos aprendido en clases anteriores, que la funci�n principal en un programa escrito en java es
        // la funci�n main. Como cualquier otra funci�n, tambien es posible indicarle parametros los cuales
        // pueden ser utilizados en la aplicaci�n cuando esta inicia.
        // Como vemos en la funci�n main,  su par�metro es "args" el cual es �nico y es un vector del
        // tipo String.
        // Cuando ejecutamos una aplicacci�n desde el CMD, colocamos el nombre del archivo .exe o similar y 
        // todas las dem�s palabras que se escriban posteriormente a la aplicaci�n, son insertados en el vector
        // de argumentos de la funci�n
        
        // Variables para el programa
        int iNumero1;
        int iNumero2;
        char cOperador;
    
        // Verifica que haya argumentos    
        if (args.length > 0)
        {
            // Ciclo para desplegar los argumentos
            for (int i = 0; i < args.length; i++) {
                System.out.println(args[i]);
            }
            
            // Verifica si necesita la ayuda
            if (args[0].equals("HELP")){
                System.out.println("argumentosmain Versi�n 1.0:");
                System.out.println("Uso");
                System.out.println("Este programa permite realizar las 4 operaciones");
                System.out.println("b�sicas matem�ticas: Suma, Resta, Multiplicacion y Divisi�n.");
                System.out.println("");
                System.out.println("La sintaxis de su uso es la siguiente:");
                System.out.println("argumentosmain valor1 operaci�n valor2");
                System.out.println("donde:");
                System.out.println("valor1 y valor2 son los operandos a usar en la operaci�n");
                System.out.println("operaci�n es uno de los siguientes carateres:M,m,p y d");
                System.out.println("s para indicar la suma");
                System.out.println("r para indicar la resta");
                System.out.println("d para indicar la divisi�n");
                System.out.println("m para indicar la multiplicaci�n");
                System.out.println("Ejemplos:");
                System.out.println("argumentosmain 5 a 5");
                System.out.println("argumentosmain 15 r 5");
                System.out.println("argumentosmain 25 d 5");
                System.out.println("argumentosmain 10 m 5");                            
            }
            else
            
                // Verifica si tiene por lo menos 3 argumentos
                if (args.length == 3) {
                    
                    // Obtiene el primer numeros
                     if (FnBoolIsInteger(args[0]))
                         iNumero1 = Integer.parseInt(args[0]);                         
                     else {
                         System.out.println("El primer argumento no es un Entero");
                         System.out.println("Para ayuda ejecute as�: argumentosmain HELP");                         
                         return;
                     }
                     
                    if (FnBoolIsInteger(args[2]))
                        iNumero2 = Integer.parseInt(args[2]);                         
                    else {
                        System.out.println("El tercer argumento no es un Entero");
                        System.out.println("Para ayuda ejecute as�: argumentosmain HELP");                         
                        return;
                    }    
                         
                    //Obtiene el operador
                    cOperador = args[1].charAt(0);
                    
                    //Verifica que tipo de operaci�n
                    switch (cOperador) {                
                        case 'a':
                            System.out.println("El resultado de la suma es:"+(iNumero1 + iNumero2));
                            break;
                        case 'r':
                            System.out.println("El resultado de la resta es:"+(iNumero1 - iNumero2));
                            break;
                        case 'd':
                            System.out.println("El resultado de la divisi�n es:"+(iNumero1 / iNumero2));
                            break;
                        case 'm':
                            System.out.println("El resultado de la multiplicaci�n es:"+(iNumero1 * iNumero2));
                            break;
                        default:
                            System.out.println("El operador no est� considerado:"+cOperador);
                            System.out.println("Para ayuda ejecute as�: argumentosmain HELP");
                            break;                    
                    } 
                }
                else
                    System.out.println("Error en la cantidad de argumentos. Para ayuda ejecute as�: argumentosmain HELP");
        }
        else
            System.out.println("Error en el uso del programa. Para ayuda ejecute as�: argumentosmain HELP");
    }
        
    private static boolean FnBoolIsInteger (String cadena)
    {
        // Captura el Error
        try
            {
            @SuppressWarnings("unused")
			int num = Integer.parseInt(cadena);
            }
            catch (Exception e)
            {
            return false;
            }
        return true;

    }    
}
