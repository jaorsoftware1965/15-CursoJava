
public class c12_precedencia {

    public static void main(String[] args) {
        
        // Clase 12. Precedencia de Operadores
        // Cuando se tiene una expresi�n matem�tica, log�ca o relacional compleja que involucra varios operadores
        // se debe de tener el conocimiento de que operaciones se ejecutar�n primero; ya que existe un orden de
        // ejecuci�n al que se le conoce como precedencia de operadores.
        // El razonamiento mas com�n es pensar que las operaciones se realizan de izquierda a derecha pero no es
        // as�. Miremos la siguiente expresi�n
        // 5 + 2 * 7        
        // Quien desconozca la precedencia de operadores, podr�a pensar que el resultado de esta expresi�n es 49
        // Ya que primero ejecutar�a 5+2=7 y posteriormente 7*7 = 49; pero no es as�.
        // El operador de multiplicaci�n tiene mayor precedencia o prioridad que el de suma, por lo que la primera
        // operaci�n que se realiza es 2*7=14 y posteriormente 14+5=19        
        // Cuando los operadores tienen la misma precedencia, entonces la ejecuci�n si se realiza de izquierda a
        // derecha. Ejemplo:  
        // 5 / 2 * 7. 
        // En el ejemplo anterior, la divisi�n y la multiplicaci�n tienen la misma precedencia, por lo que la 
        // ejecuci�n se realiza de izquierda a derecha: 5/2= 2.5 * 7=  17.5
                
        // La siguiente lista muestra la precedencia de operadores; en donde los que est�n arriba de la lista, tienen
        // mayor precedencia que los que est�n debajo.
        
        //  [ ] . ( ) (en llamada a funci�n)
        //  � ~ ++ -- +(unario) �(unario) ( ) (en cast) new
        //  * / %
        //  + -
        //  << >> >>>
        //  < <= > >= instanceof
        //  == �=
        //  &^|
        //  &&
        //  ||
        //  ?:
        //  = += -= *= /= %= &= |= ^= <<= >>= >>>=
        
        // Definimos variables para ejemplos
        int x=5;    
        int y=12;
        int z=10;
        
        // Calcule cual ser�a el valor de z para las siguientes operaciones
        z = x-- / 5 * 4 + ( 3 * 9);
        z = ++y + x++ * 3;
        z = (-y + -x) / 6;
        z = (-y * x + z) / (6 + 8 + z / 4);
        z = x << 1 * 10;
        z = (x << 1) * 10;
        z = 0;
        z+= 5 * 8;
        z*= 5 + 8;
        z= 10;
        z%=2 + 5;
        z%=2 * 5 / 5 + 4;
        
    }
}
