public class c19_parametros {
    public static void main(String[] args) {
        
        // Clase 19. Par�metros
        // Un parametro es un dato o informaci�n que se define en un Procedimiento o en una Funci�n para que esta pueda
        // ejecutarse correctamente. Hasta el momento, los procedimientos o funciones que hemos visto, no han necesitado
        // par�metros. En esta clase los veremos.
        // Para definir un par�metro o mas en una funci�n estos deben de colocarse dentro del par�ntesis de la funci�n
        // o procedimiento, separados cada uno de ellos por ",". Cada par�metro debe tener su tipo de dato indicado; tal
        // y como lo realizamos cuando declaramos una variable.
                
        // Variables
        @SuppressWarnings("unused")
		int iNumero=10;
        String strMensajeOriginal="Hola Mundo";
        int[] intArrCalificaciones = {90,97,66,45,34,23,15,78,90,89};
            
        // Ciclo que imprime tabla de multiplicar
        SbDespliegaMensaje(strMensajeOriginal);            
                    
        // Ciclo que imprime tabla de multiplicar
        System.out.println("La Suma:"+FnIntSumaVector(intArrCalificaciones));                    
                
    }
    private static void SbDespliegaMensaje(String vStrMensaje){
        
        // Ciclo que imprime tabla de multiplicar
        System.out.println(vStrMensaje);            
                
        // Ciclo que imprime tabla de multiplicar
        System.out.println(vStrMensaje);            
        
    }
    private static int FnIntSumaVector(int[] Vector){
        
        // Variable para sumar el vector
        int iSuma=0;
        
        // Variable para contar los elementos
        int iCta;
        
        // Ciclo para sumar los elementos
        for  (iCta=0; iCta<Vector.length; iCta++) {
            
            // Suma el elemento
            iSuma += Vector[iCta];
            Vector[iCta]=0;
            
        }
        
        // Devuelve la SUma
        return iSuma;
        
    }
}
