
public class c03_cadenas {

    public static void main(String[] args) {
        // Clase 03 - Cadenas
        
        // Las variables de tipo String; ya no son primitivas; ya son variables objeto de una clase; en este caso
        // de la Clase String.
        
        // A continuaci�n veremos las principales funciones de la Clase String
        
        // Considerar que las posiciones inician desde 0 hasta longitud de cadena -1       
        String StringVariable="JaorSoftware";
        
        // Imprime el Mensaje a Out
        System.out.println("El valor de la variable String:"+StringVariable);
        
        // Imprime la longitud de la variable
        System.out.println("Longitud de la variable String:"+StringVariable.length());
        
        // Imprime una subcadena de la variable
        System.out.println("Subcadena de la variable String:"+StringVariable.substring(0,4));
        System.out.println("Subcadena de la variable String:"+StringVariable.substring(4));
        System.out.println("Subcadena de la variable String:"+StringVariable.substring(4,6));
        
        //Devuelve el caracter de una posicion indicada
        System.out.println("CharAt de la variable String:"+StringVariable.charAt(4));
        
        //Compara
        System.out.println("equals de la variable String:"+StringVariable.equals("jaorsoftware"));
        System.out.println("equals de la variable String:"+StringVariable.equals("JaorSoftware"));
        System.out.println("equalsIgnoreCase de la variable String:"+StringVariable.equalsIgnoreCase("jaorsoftware"));
        
        // Compara contra cadena
        System.out.println("compareTo de la variable String:"+StringVariable.compareTo("JaorSoftware"));
        System.out.println("compareTo de la variable String:"+StringVariable.compareTo("JaorSoftwa"));
        System.out.println("compareTo de la variable String:"+StringVariable.compareTo("JaorSoftw"));
        System.out.println("compareTo de la variable String:"+StringVariable.compareTo("Kilo"));
        System.out.println("compareTo de la variable String:"+StringVariable.compareTo("Igual"));
        
        // Busca posiciones con LastIndexOf
        System.out.println("lastIndexOf de la variable String:"+StringVariable.indexOf("Jaor"));
        System.out.println("lastIndexOf de la variable String:"+StringVariable.indexOf("Softwa"));
        System.out.println("lastIndexOf de la variable String:"+StringVariable.indexOf("oftw"));
        System.out.println("lastIndexOf de la variable String:"+StringVariable.indexOf("K"));    
        
        // Busca posiciones con concat
        System.out.println("concat de la variable String:"+StringVariable.concat(" Consultor"));
        System.out.println("concat de la variable String:"+StringVariable.concat(" Freelance"));
        System.out.println("concat de la variable String:"+StringVariable.concat(" Programmer"));
        System.out.println("concat de la variable String:"+StringVariable.concat(" Sistemas"));    
        
        // Lower and Upper Case 
        System.out.println("toLowerCase de la variable String:"+StringVariable.toLowerCase());
        System.out.println("toUpperCase de la variable String:"+StringVariable.toUpperCase());
        
        // Replace
        System.out.println("replace de la variable String:"+StringVariable.replace("Jaor","Olmedo"));
        System.out.println("replace de la variable String:"+StringVariable.replace("Software","System"));
        
        // Contain
        System.out.println("contains de la variable String:"+StringVariable.contains("Jaor"));
        System.out.println("contains de la variable String:"+StringVariable.contains("Soft"));
        
        // Starts
        System.out.println("startsWith de la variable String:"+StringVariable.startsWith("Jaor"));
        System.out.println("startsWith de la variable String:"+StringVariable.startsWith("Soft"));

        // End
        System.out.println("endsWith de la variable String:"+StringVariable.endsWith("ware"));
        System.out.println("endsWith de la variable String:"+StringVariable.endsWith("stem"));
        
        // Tarea. Investigar 3 funciones mas de cadena
    
    }

}
