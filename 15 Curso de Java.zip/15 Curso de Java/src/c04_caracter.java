
public class c04_caracter {
    @SuppressWarnings("static-access")
	public static void main(String[] args) {
        // Clase 04 - Caracter
        
        // Las variables de tipo Character; tampoco son primitivas; ya que son variables objeto de una clase; 
        // en este caso de la Clase Character.
        
        // La clase caracter permite utilizar sus funciones, sin necesidad de hacer referencia de una variable
        // A continuaci�n veremos las principales funciones de la Clase String        
        
        // Declaro una variable-objeto
        Character CharacterVariable='J';
        
        // Imprime el valor de la variable
        System.out.println("El valor de la variable Character:" + CharacterVariable.charValue());
        
        // Compara
        System.out.println("compareTo de la variable Character:" + CharacterVariable.compareTo('k'));
        System.out.println("compareTo de la variable Character:" + CharacterVariable.compareTo('j'));
        System.out.println("compareTo de la variable Character:" + CharacterVariable.compareTo('J'));
        System.out.println("compareTo de la variable Character:" + CharacterVariable.compareTo('K'));
        System.out.println("compareTo de la variable Character:" + CharacterVariable.compareTo('I'));
        
        // Equals
        System.out.println("equals de la variable Character:" + CharacterVariable.equals('J'));
        System.out.println("equals de la variable Character:" + CharacterVariable.equals('M'));
        
        // Funciones independientes del Valor de la Variabll
        // getNumericValue
        System.out.println("Funci�n getNumericValue:" + CharacterVariable.getNumericValue('0'));
        System.out.println("Funci�n getNumericValue:" + CharacterVariable.getNumericValue('1'));
        System.out.println("Funci�n getNumericValue:" + CharacterVariable.getNumericValue('2'));
        System.out.println("Funci�n getNumericValue:" + CharacterVariable.getNumericValue('3'));
        System.out.println("Funci�n getNumericValue:" + CharacterVariable.getNumericValue('4'));
        System.out.println("Funci�n getNumericValue:" + CharacterVariable.getNumericValue('5'));
        System.out.println("Funci�n getNumericValue:" + CharacterVariable.getNumericValue('6'));
        System.out.println("Funci�n getNumericValue:" + CharacterVariable.getNumericValue('7'));
        System.out.println("Funci�n getNumericValue:" + CharacterVariable.getNumericValue('8'));
        System.out.println("Funci�n getNumericValue:" + CharacterVariable.getNumericValue('9'));
        System.out.println("Funci�n getNumericValue:" + CharacterVariable.getNumericValue('a'));
        System.out.println("Funci�n getNumericValue:" + CharacterVariable.getNumericValue('A'));
        System.out.println("Funci�n getNumericValue:" + CharacterVariable.getNumericValue('Z'));
        System.out.println("Funci�n getNumericValue:" + CharacterVariable.getNumericValue(';'));
        System.out.println("Funci�n getNumericValue:" + CharacterVariable.getNumericValue('*'));
        
        // getName
        System.out.println("Funci�n getName de a:" + CharacterVariable.getName('a'));
        System.out.println("Funci�n getName de b:" + CharacterVariable.getName('b'));
        System.out.println("Funci�n getName de C:" + CharacterVariable.getName('C'));
        System.out.println("Funci�n getName de Z:" + CharacterVariable.getName('Z'));
        
        // isSpaceChar
        System.out.println("Funci�n isSpaceChar de A:" + CharacterVariable.isSpaceChar('A'));
        System.out.println("Funci�n isSpaceChar de space:" + CharacterVariable.isSpaceChar(' '));
        
        // isAlphabetic
        System.out.println("Funci�n isAlphabetic de A:" + CharacterVariable.isAlphabetic('A'));
        System.out.println("Funci�n isAlphabetic de 0:" + CharacterVariable.isAlphabetic('0'));
        
        // isDigit
        System.out.println("Funci�n isDigit de A:" + CharacterVariable.isDigit('A'));
        System.out.println("Funci�n isDigit de 0:" + CharacterVariable.isDigit('0'));
        
        // isLetterOrDigit
        System.out.println("Funci�n isLetterOrDigit de A:" + CharacterVariable.isLetterOrDigit('A'));
        System.out.println("Funci�n isLetterOrDigit de 0:" + CharacterVariable.isLetterOrDigit('0'));
        System.out.println("Funci�n isLetterOrDigit de ,:" + CharacterVariable.isLetterOrDigit(','));
        
        // isLower o Upper Case
        System.out.println("Funci�n isLowerCase de A:" + CharacterVariable.isLowerCase('A'));
        System.out.println("Funci�n isUpperCase de a:" + CharacterVariable.isUpperCase('a'));
        System.out.println("Funci�n isLowerCase de A:" + CharacterVariable.isLowerCase('a'));
        System.out.println("Funci�n isUpperCase de A:" + CharacterVariable.isUpperCase('A'));
        
        // isWhiteSpace
        System.out.println("Funci�n isWhiteSpace de A:" + CharacterVariable.isWhitespace('.'));
        System.out.println("Funci�n isWhiteSpace de a:" + CharacterVariable.isWhitespace(' '));
        
        // toLower o toUpper Case
        System.out.println("Funci�n toLowerCase de A:" + CharacterVariable.toLowerCase('A'));
        System.out.println("Funci�n toUpperCase de a:" + CharacterVariable.toUpperCase('a'));
               
        // Tarea. Investigar 3 funciones mas de cadena y caracter
        
    }

}
