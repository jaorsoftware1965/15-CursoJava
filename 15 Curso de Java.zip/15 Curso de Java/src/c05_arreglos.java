import java.util.Arrays;
public class c05_arreglos {
    public static void main(String[] args) {
        // Clase 05. Arreglos
        // Un arreglo es un conunto de "n" espacios en memoria dispuestos para almacenar informaci�n del mismo tipo
        // en donde a cada elemento se le accede a trav�s de un �ndice. Por ejemplo. Si preparo 10 cajas de cart�n
        // y las etiqueto a todas con la palabra "MANZANAS" cubriendo con ella las 10 cajas; y a cada caja la  numero
        // a partir del 0 hasta el 9; tendr� entonces que la primera caja es referenciada como MANZANAS[0], la segunda
        // caja MANZANAS[1], y as� sucesicamente hasta llegar a MANZANAS[9]. Con esta referencia puedo depositar u 
        // obtener las MANZANAS que hay en cada caja.
        
        
        // Arreglo para almanenar 10 calificaciones
        int[] intArrCalificaciones;
        intArrCalificaciones = new int[10];
        
        // Lo anterior tambien puede escribirse en una sola l�nea
        int[] intArrCalificaciones2 = new int[10];
        
        // Coloco las 10 calificaciones
        intArrCalificaciones[0]=97;
        intArrCalificaciones[1]=69;
        intArrCalificaciones[2]=77;
        intArrCalificaciones[3]=89;
        intArrCalificaciones[4]=88;
        intArrCalificaciones[5]=78;
        intArrCalificaciones[6]=90;
        intArrCalificaciones[7]=68;
        intArrCalificaciones[8]=90;
        intArrCalificaciones[9]=80;
        
        // Imprimo las calificaciones
        System.out.println("Califaci�n  1 que ocupa la posici�n 0:"+intArrCalificaciones[0]);
        System.out.println("Califaci�n  2 que ocupa la posici�n 1:"+intArrCalificaciones[1]);
        System.out.println("Califaci�n  3 que ocupa la posici�n 2:"+intArrCalificaciones[2]);
        System.out.println("Califaci�n  4 que ocupa la posici�n 3:"+intArrCalificaciones[3]);
        System.out.println("Califaci�n  5 que ocupa la posici�n 4:"+intArrCalificaciones[4]);
        System.out.println("Califaci�n  6 que ocupa la posici�n 5:"+intArrCalificaciones[5]);
        System.out.println("Califaci�n  7 que ocupa la posici�n 6:"+intArrCalificaciones[6]);
        System.out.println("Califaci�n  8 que ocupa la posici�n 7:"+intArrCalificaciones[7]);
        System.out.println("Califaci�n  9 que ocupa la posici�n 8:"+intArrCalificaciones[8]);
        System.out.println("Califaci�n 10 que ocupa la posici�n 9:"+intArrCalificaciones[9]);
        
        // Arreglo para almacenar Nombre
        String[] StrArrNombres = new String[10];
        StrArrNombres[0]="Jos�";
        StrArrNombres[1]="Mar�a";
        StrArrNombres[2]="Alba";
        StrArrNombres[3]="Daniel";
        StrArrNombres[4]="Manolo";
        StrArrNombres[5]="Miguel";
        StrArrNombres[6]="Gloria";
        StrArrNombres[7]="Carmen";
        StrArrNombres[8]="Lourdes";
        StrArrNombres[9]="Jaqueline";
        
        // Imprimo los nombres
        System.out.println("Nombre  1 que ocupa la posici�n 0:"+StrArrNombres[0]);
        System.out.println("Nombre  2 que ocupa la posici�n 1:"+StrArrNombres[1]);
        System.out.println("Nombre  3 que ocupa la posici�n 2:"+StrArrNombres[2]);
        System.out.println("Nombre  4 que ocupa la posici�n 3:"+StrArrNombres[3]);
        System.out.println("Nombre  5 que ocupa la posici�n 4:"+StrArrNombres[4]);
        System.out.println("Nombre  6 que ocupa la posici�n 5:"+StrArrNombres[5]);
        System.out.println("Nombre  7 que ocupa la posici�n 6:"+StrArrNombres[6]);
        System.out.println("Nombre  8 que ocupa la posici�n 7:"+StrArrNombres[7]);
        System.out.println("Nombre  9 que ocupa la posici�n 8:"+StrArrNombres[8]);
        System.out.println("Nombre 10 que ocupa la posici�n 9:"+StrArrNombres[9]);
        
        // M�todos o Funciones que tensmos disponibles
        System.out.println("Cuantos elementos tiene el Arreglo de Calificaciones:"+intArrCalificaciones.length);
        System.out.println("Cuantos elementos tiene el Arreglo de Nombres:"+StrArrNombres.length);
        
        // Al acceder al elemento individualmente, tenemos acceso a sus propiedades
        System.out.println("Cuantos elementos tiene el Arreglo de Nombres:"+StrArrNombres[0].concat("Alumno"));
        
        // Otra forma de inicializar
        int[] intArrVelocidades = { 100, 120, 130, 46, 56, 96, 87, 80, 90, 100 };
        
        // Desplegando las velocidades
        System.out.println("Velocidad  1 que ocupa la posici�n 0:"+intArrVelocidades[0]);
        System.out.println("Velocidad  2 que ocupa la posici�n 1:"+intArrVelocidades[1]);
        System.out.println("Velocidad  3 que ocupa la posici�n 2:"+intArrVelocidades[2]);
        System.out.println("Velocidad  4 que ocupa la posici�n 3:"+intArrVelocidades[3]);
        System.out.println("Velocidad  5 que ocupa la posici�n 4:"+intArrVelocidades[4]);
        System.out.println("Velocidad  6 que ocupa la posici�n 5:"+intArrVelocidades[5]);
        System.out.println("Velocidad  7 que ocupa la posici�n 6:"+intArrVelocidades[6]);
        System.out.println("Velocidad  8 que ocupa la posici�n 7:"+intArrVelocidades[7]);
        System.out.println("Velocidad  9 que ocupa la posici�n 8:"+intArrVelocidades[8]);
        System.out.println("Velocidad 10 que ocupa la posici�n 9:"+intArrVelocidades[9]);
        
        // Longitud del Vector
        System.out.println("Cuantos elementos tiene el Arreglo de Velocidades:"+intArrVelocidades.length);
        
        // Funciones para los arreglos
        Arrays.sort(intArrCalificaciones);
        
        // Despliegue de las calificaciones Sorteadas
        System.out.println("Califaci�n  1 que ocupa la posici�n 0:"+intArrCalificaciones[0]);
        System.out.println("Califaci�n  2 que ocupa la posici�n 1:"+intArrCalificaciones[1]);
        System.out.println("Califaci�n  3 que ocupa la posici�n 2:"+intArrCalificaciones[2]);
        System.out.println("Califaci�n  4 que ocupa la posici�n 3:"+intArrCalificaciones[3]);
        System.out.println("Califaci�n  5 que ocupa la posici�n 4:"+intArrCalificaciones[4]);
        System.out.println("Califaci�n  6 que ocupa la posici�n 5:"+intArrCalificaciones[5]);
        System.out.println("Califaci�n  7 que ocupa la posici�n 6:"+intArrCalificaciones[6]);
        System.out.println("Califaci�n  8 que ocupa la posici�n 7:"+intArrCalificaciones[7]);
        System.out.println("Califaci�n  9 que ocupa la posici�n 8:"+intArrCalificaciones[8]);
        System.out.println("Califaci�n 10 que ocupa la posici�n 9:"+intArrCalificaciones[9]);
        
        // Funciones para los arreglos
        Arrays.sort(StrArrNombres);
        
        // Imprimo los nombres
        System.out.println("Nombre  1 que ocupa la posici�n 0:"+StrArrNombres[0]);
        System.out.println("Nombre  2 que ocupa la posici�n 1:"+StrArrNombres[1]);
        System.out.println("Nombre  3 que ocupa la posici�n 2:"+StrArrNombres[2]);
        System.out.println("Nombre  4 que ocupa la posici�n 3:"+StrArrNombres[3]);
        System.out.println("Nombre  5 que ocupa la posici�n 4:"+StrArrNombres[4]);
        System.out.println("Nombre  6 que ocupa la posici�n 5:"+StrArrNombres[5]);
        System.out.println("Nombre  7 que ocupa la posici�n 6:"+StrArrNombres[6]);
        System.out.println("Nombre  8 que ocupa la posici�n 7:"+StrArrNombres[7]);
        System.out.println("Nombre  9 que ocupa la posici�n 8:"+StrArrNombres[8]);
        System.out.println("Nombre 10 que ocupa la posici�n 9:"+StrArrNombres[9]);
        
        // B�squeda
        System.out.println("Posici�n del Elemento en el vector:"+Arrays.binarySearch(intArrCalificaciones, 77));
        
        // Copiando elementos del Vector a otro
        intArrCalificaciones2=Arrays.copyOf(intArrCalificaciones, 2);
        System.out.println("Califaci�n  1 que ocupa la posici�n 0:"+intArrCalificaciones2[0]);
        System.out.println("Califaci�n  2 que ocupa la posici�n 1:"+intArrCalificaciones2[1]);
        
        // Llenando el vector con el elemento indicado
        Arrays.fill(intArrCalificaciones, 77);
        System.out.println("Califaci�n  1 que ocupa la posici�n 0:"+intArrCalificaciones[0]);
        System.out.println("Califaci�n  2 que ocupa la posici�n 1:"+intArrCalificaciones[1]);
        System.out.println("Califaci�n  3 que ocupa la posici�n 2:"+intArrCalificaciones[2]);
        System.out.println("Califaci�n  4 que ocupa la posici�n 3:"+intArrCalificaciones[3]);
        System.out.println("Califaci�n  5 que ocupa la posici�n 4:"+intArrCalificaciones[4]);
        System.out.println("Califaci�n  6 que ocupa la posici�n 5:"+intArrCalificaciones[5]);
        System.out.println("Califaci�n  7 que ocupa la posici�n 6:"+intArrCalificaciones[6]);
        System.out.println("Califaci�n  8 que ocupa la posici�n 7:"+intArrCalificaciones[7]);
        System.out.println("Califaci�n  9 que ocupa la posici�n 8:"+intArrCalificaciones[8]);
        System.out.println("Califaci�n 10 que ocupa la posici�n 9:"+intArrCalificaciones[9]);
        
        // Veririca que sean iguales
        System.out.println(Arrays.equals(intArrCalificaciones, intArrVelocidades));
        System.out.println(Arrays.equals(intArrCalificaciones, intArrCalificaciones));                          
    }
	
}
