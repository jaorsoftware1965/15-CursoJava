import java.io.File;
import java.io.IOException;


public class c35_archivos {
	
	public static void main(String[] args) 
	{
        /* 
         * Clase 35 - Archivos
         * 
         * Un Archivo es un área de Memoria Secundaria que se utiliza para almacenar 
         * información.
         * 
         * Memoria Secundaria quiere decir que se encuentra en un Disco Duro; o en cualquier
         * otro dispositivo de almacenamiento similar.
         * 
         * Cada Archivo tiene un Nombre que lo identifica y que es único en el directorio en
         * el que se encuentre grabado.
         * 
         * Para realizar el Manejo de archivos, Java proporciona algunas Clases diseñadas
         * específicamente para ello; las cuales veremos a continuación.
         * 
         * File.
         * La clase File sirve para representar archivos o directorios en el sistema de
         * archivos de la plataforma específica. Mediante esta clase pueden obtenerse las
         * particularidades de cada sistema de archivos y proporcionar los métodos
         * necesarios para obtener información sobre los mismos.
         * 
         * A Continuación se presenta la forma en que se encuentra definida la Clase:
         * 
         * public class java.io.File implements Serializable 
         * {
         * 		// Atributos
         * 		public static final String pathSeparator; // separador de paths
         * 		public static final char pathSeparatorChar; // separador de paths
         * 		public static final String separator; // separador de directorios en un path
         * 		public static final char separatorChar; // separador de directorios en un path

         * 		// Constructores
         * 		public File(String pathYNombre);
         * 		public File(String path, String nombre);
         * 		public File(File path, String nombre);

         * 		// Métodos
         * 		public boolean canRead(); // true si permite la lectura
         * 		public boolean canWrite(); // true si permite la escritura
         * 		public boolean delete(); // borrar el fichero
         * 		public boolean exists(); // true si existe el fichero
         * 		public String getAbsolutePath(); // obtiene el path absoluto
         * 		public String getCanonicalPath() throws IOException; // path canónico
         * 		public String getName(); // obtiene el nombre del fichero o directorio
         * 		public String getParent(); // obtiene el path del directorio padre
         * 		public String getPath(); // obtiene el path del fichero
         * 		public int hashCode(); // devuelve un código hash para el fichero
         * 		public native boolean isAbsolute(); // true si el path es absoluto
         * 		public boolean isDirectory(); // true si es un directorio y no un fichero
         * 		public boolean isFile(); // true si es un fichero
         * 		public long lastModified(); // Devuelve el momento de la última modificación
         * 		public long length(); // Devuelve el tamaño en bytes del fichero
         * 		public String[] list(); // Devuelve los ficheros de un directorio
         * 		public String[] list(FilenameFilter filtro); // igual que anterior con filtro
         * 		public boolean mkdir(); // Crea el directorio indicado
         * 		public boolean mkdirs(); // Crea todos los directorios del path necesarios
         * 		public boolean renameTo(File destino); // Cambia el nombre por destino
         * }
         * 
         * 
         * */
		
		// Creamos un Archivo
		File fPrueba = new File("src");
		
		// Desplegamos la información del Archivo que proporciona la Clase
		System.out.println("pathSeparator: "+File.pathSeparator);		
		System.out.println("pathSeparatorChar: "+File.pathSeparatorChar);
		System.out.println("separator: "+File.separator);
		System.out.println("separatorChar: "+File.separatorChar);
		
		try 
		{
			System.out.println("canRead():"+fPrueba.canRead());
			System.out.println("canWrite():"+fPrueba.canWrite());
			System.out.println("exists():"+fPrueba.exists());
			System.out.println("getAbsolutePath():"+fPrueba.getAbsolutePath());
			System.out.println("getCanonicalPath():"+fPrueba.getCanonicalPath());
			System.out.println("getName():"+fPrueba.getName());
			System.out.println("getParent():"+fPrueba.getParent());
			System.out.println("getPath():"+fPrueba.getPath());
			System.out.println("hashCode():"+fPrueba.hashCode());
			System.out.println("isAbsolute():"+	fPrueba.isAbsolute());
			System.out.println("isDirectory():"+fPrueba.isDirectory());
			System.out.println("isFile():"+fPrueba.isFile());
			System.out.println("lastModified():"+fPrueba.lastModified());
			System.out.println("length():"+fPrueba.length());
		} 
		// Captura el Error de Entrada y Salida (Input-Output)
		catch (IOException e) 
		{
			System.out.println(e); 
		}
    }


}