
public class c15_estructura_control_while {
    public static void main(String[] args) {        
        // Clase 15. Estructuras de Control III. Ciclos while y do-while.
        // Los Ciclos, son estructuras de control que nos permiten repetir bloques de código "n" veces, mientras que
        // una condición se cumpla. En esta clase veremos la estructuras while y la estructura do-while.
        
        // La estructura while(condición) nos permite ejecutar un bloque de código repetidas veces, mientras que
        // condición sea cierto. Para que se ejecute por lo menos una vez el bloque de código de la instruccion, 
        // condición debe ser verdad por lo menos una vez; antes de que se ejecute la instruccion while.
        // La sintaxis del uso de esta instrucción es:
        
        // while (condición)
        // {
        //    bloque de código;
        // }

        // condición debe ser verdad para que el bloque de código se ejecute; y debe haber alguna instrucción dentro
        // del bloque de código o fuera de este; que cambie la condición a false; para que de esta forma el ciclo no
        // se vuelva infinito. Cuando la condición cambie a false, finalizará la ejecución de la sentencia while
        
        // La estructura do-while(condición) es similar a la instrucción while; solo que la condicion se evalúa 
        // al final de bloque de código; por lo que para entrar al bloque no es necesaria que la condición sea
        // verdadera. Si la condición es verdadera; al igual que con la sentencia while, deberá haber alguna instrucción
        // dentro del bloque o fuera de este; que cambie la condición a false; para que la sentencia finalice
        // La sintaxis del uso de esta instrucción es:
        
        // do
        // {
        //    bloque de código;
        // }while (condición);
        
        // Ejemplos
        int x=0;
        
        System.out.println("Primer Ciclo while");
        // Ciclo que imprime el valor de x 9 veces
        while (x++<10)
        {
            System.out.println("El valor de x:"+x);
        }
        x=0;
        
        System.out.println("");
        
        System.out.println("Segundo Ciclo While");        
        do
        {
            System.out.println("El valor de x:"+x);
        }
        while(x++<10);
    }
}
