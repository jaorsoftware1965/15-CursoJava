import java.util.Date;



// Defino la Clase Persona
class classPersona3 {
        
    // Definimos las propiedades
    String strNombre;
    String strApellido;
    char   chrSexo;
    int    intEdad;
    char   chrEdoCivil;
    private String strDireccion;
    
    // Constructor de la Clase
    classPersona3(){
    
        strNombre= "Juan";
        strApellido="Pérez";
        chrSexo ='H';
        intEdad=33;
        chrEdoCivil='S';
    }

    // Constructor de la Clase con Parámetros
    classPersona3(String pNombre){
    
        strNombre= pNombre;
        strApellido="";
        chrSexo =32;
        intEdad=0;
        chrEdoCivil=32;
    }
    
    // Procedimiento para definir la Dirección
    void SbSetAddress(String pAddress){
        
        // Establece la dirección
        strDireccion = pAddress;
        
    }
    // Método que obtiene la dirección
    String  fnStrGetAddress(){
        
        // Retorna la Dirección
        return strDireccion;
    }
    
    // Método para Imprimir la Información
    void SbPrintPersonaInfo() {
        
        // Imprime la Informacion del Cliente        
        System.out.println("Personal Info Clase 3\n");
        System.out.println("Nombre:"+strNombre);
        System.out.println("Apellido:"+strApellido);
        if (chrSexo=='H')
           System.out.println("Sexo:Hombre");
        else
            if (chrSexo=='M')
               System.out.println("Sexo:Mujer");
            else
               System.out.println("Sexo:Falta indicar");
        System.out.println("Edad:"+intEdad);
        System.out.print("Estado Civil:");        
        switch (chrEdoCivil) {        
        case 'S':
            System.out.println("Soltero");
            break;
        case 'C':
            System.out.println("Casado");
            break;
        case 'V':
            System.out.println("Viudo");
            break;
        case 'U':
            System.out.println("Unión Libre");
            break;
        default:
            System.out.println("No Registrado");
        }        
    }

    
}

// Clase Abstracta
abstract class classEmpleado2 extends classPersona3 {

    // Definimos las propiedades
    private float fSueldo;
    @SuppressWarnings("unused")
	private Date dIngreso = new Date();
    String sDepartamento;

    // Constructor de la Clase
    classEmpleado2(float pSueldo, Date pIngreso, String pDepartamento) {

        // Asigna Sueldo, Fecha de Ingreso y Departamento
        fSueldo = pSueldo;
        dIngreso = pIngreso;
        sDepartamento = pDepartamento;

    }
    // Constructor de la Clase
    classEmpleado2(String pNombre, float pSueldo, Date pIngreso, String pDepartamento) {


        // Asigna Sueldo, Fecha de Ingreso y Departamento
        super(pNombre);
        fSueldo = pSueldo;
        dIngreso = pIngreso;
        sDepartamento = pDepartamento;

    }
    // Procedimiento para definir la Direcci�n
    void SbSetSueldo(float pSueldo) {

        // Establece la dirección
        fSueldo = pSueldo;

    }

    // Método que obtiene la dirección
    float fnfloatGetSueldo() {

        // Retorna la Dirección
        return fSueldo;
    }
    
    // Método para Imprimir la Información se REESCRIBE
    void SbPrintPersonaInfo() {
        
        // Imprime la Informacion del Cliente        
        System.out.println("Personal Info Clase 2 ");
        System.out.println("Nombre:"+strNombre);
        System.out.println("Apellido:"+strApellido);
        if (chrSexo=='H')
           System.out.println("Sexo:Hombre");
        else
            if (chrSexo=='M')
               System.out.println("Sexo:Mujer");
            else
               System.out.println("Sexo:Falta indicar");
        System.out.println("Edad:"+intEdad);
        System.out.print("Estado Civil:");        
        switch (chrEdoCivil) {        
        case 'S':
            System.out.println("Soltero");
            break;
        case 'C':
            System.out.println("Casado");
            break;
        case 'V':
            System.out.println("Viudo");
            break;
        case 'U':
            System.out.println("Uni�n Libre");
            break;
        default:
            System.out.println("No Registrado");
        }
        System.out.println("");
    }

    // Metodo abstracto
    abstract float fnfloatGetComision();
    
}

class classEmpleadoA extends classEmpleado2 {
    
    classEmpleadoA(){
        super(3456,new Date(),"Contabilidad");
    }
    float fnfloatGetComision() {
        return (float) (fnfloatGetSueldo() * .10);    
    }
}

class classEmpleadoB extends classEmpleado2 {
    classEmpleadoB(){
        super(4555,new Date(),"Informatica");
    }
    float fnfloatGetComision() {
        return (float) (fnfloatGetSueldo() * .20);    
    }
}

public class c25_poo_polimorfismo {

    public static void main(String[] args) {
        
        // Clase 25. Programación Orientada a Objetos IV
        // Temas: Polimorfismo
        // Otro de los aspectos muy importantes en la programación Orientada a Objetos, es el Polimorfismo.
        // El Polimorfismo es la capacidad que tiene una Clase de poder actuar a través de un mismo método
        // pero de diferente forma; dependiendo de la clase que la Herede.
        // Para poder definir esta característica en una clase:
        
        // a) utilizamos la palabra reservada abstract al definir la clase Padre
        // b) utilizamos de nueva cuenta la palabra abstract para aquellos métodos que deberán actuar en forma
        // distinta dependiendo de la clase Hija a quien se herede
        // c) los métodos definidos abstract en la clase Padre, se quedan vacíos; es decir; sin código; 
        // unicamente definidos.
        // d) en la clase Hija es posible implementar cada uno de los métodos abstract, como cualquier otro
        // método de la clase. Ejemplo
        
        // Si tenemos una Clase Padre definida para los Empleados, tenemos que definir un método que 
    	// permita calcular una Comisión en base al sueldo; pero que esta comisión se calcule de diferente 
    	// forma dependiendo de cada una de las clases Hijas que definan al tipo de Empleado.
    	
    	// Al utilizar la palabra reservada abstract, estamos definiendo una Clase Abstracta.	
    	
    	// Caracteristicas de una Clase Abstracta. 

    	// - Una clase Abstracta No puede ser instanciada (no se pueden crear objetos directamente - new ),
    	//   solo puede ser heredada. 
    	// - Si al menos un método de la clase es abstract, esto obliga a que la clase completa sea 
    	//   definida abstract, sin embargo la clase puede tener el resto de métodos no abstractos.
    	// - Los métodos abstract no llevan cuerpo (no llevan los caracteres {}). 
    	// - La primer subclase concreta que herede de una clase abstract debe implementar todos los 
    	//   métodos de la superclase.
                
        // Defino objeto de las Clases
    	// No puedo definir de la Clase abstrac solo de sus hijas
        classEmpleadoA oEmpleadoA  = new classEmpleadoA();
        classEmpleado2 oEmpleado1A = new classEmpleadoA(); // Igual que anterior
        classEmpleadoB oEmpleadoB  = new classEmpleadoB();
        classEmpleado2 oEmpleado1B = new classEmpleadoB(); // Igual que anterior
        classPersona3 xEmpleado = new classEmpleadoB();
               
        
        // Imprimo la comisión
        System.out.println("Comisión Empleado  A:"+oEmpleadoA.fnfloatGetComision());
        System.out.println("Comisión Empleado 1A:"+oEmpleado1A.fnfloatGetComision());
        System.out.println("Comisión Empleado  B:"+oEmpleadoB.fnfloatGetComision());        
        System.out.println("Comisión Empleado 1B:"+oEmpleado1B.fnfloatGetComision());
        System.out.println("");
        
        
        // En ambos casos, el método que se ejecuta está definido en la clase Empleado; pero el 
        // código que se ejecuta es el que se encuentra en cada una de las clases hijas; las de 
        // los tipos de Empledo.
        oEmpleadoA.SbPrintPersonaInfo();
        oEmpleado1A.SbPrintPersonaInfo();
        oEmpleadoB.SbPrintPersonaInfo();        
        oEmpleado1B.SbPrintPersonaInfo();
        xEmpleado.SbPrintPersonaInfo();
    }
}
