class Alumno 
{
    @SuppressWarnings("unused")
	private String nombre;
    @SuppressWarnings("unused")
	private String apellido;
    @SuppressWarnings("unused")
	private Integer edad;
 
    public Alumno(String nombre, String apellido, Integer edad) throws Exception 
    {
       this.nombre = nombre;
       this.apellido = apellido;
       if (edad <= 0){
            throw new Exception("La edad debe ser mayor a cero");
        }else{
            this.edad = edad;
        }
    }
 
    public void setNombre(String nombre)  throws Exception  
    {
    	if (nombre.equals(""))
    		throw new Exception("El nombre no puede estar vacío");
        this.nombre = nombre;
    }
}

public class c26_excepciones {

    public static void main(String[] args) {
        // Clase 26. Excepciones
        // Las excepciones son un mecanismo que presentan los lenguajes más modernos para 
    	// ejecutar código aparte del control de flujo habitual cuando se producen ciertos 
    	// errores o condiciones anormales de ejecución. Constituyen una alternativa menos 
    	// tediosa y más segura que el control de errores clásico usado para escribir 
    	// aplicaciones robustas.
        
        // En el lenguaje Java, la clase Exception define condiciones de error que los 
    	// programas pueden encontrar.
        // En vez de dejar que el programa termine, se puede escribir código para gestionar 
    	// estas condiciones de error y continuar con la ejecución del programa.
        
        // Cualquier situación anormal que rompe la ejecución normal del programa se 
    	// denomina error o excepción. Las excepciones se producen por ejemplo cuando:
        // - Un Archivo que se quiere abrir no existe.
        // - La conexión de red se ha perdido.
        // - Los operandos que se manejan se salen de rango.
        // - El Archivo de clase que se quiere cargar no existe.

    	// Se puede concluir que una Excepción es un Error Identificado o Esperado
    	
        // Que es un error
        // En el lenguaje Java, la clase Error define aquellas condiciones que se consideran 
    	// como errores serios de los que es preferible no recuperar la ejecución. 
    	// La mayoría de veces es aconsejable dejar que el programa termine.
           
        // El lenguaje Java implementa excepciones al estilo de C++ para ayudar a escribir 
    	// código robusto.
        // Cuando se genera un error en un programa, el método que encuentra dicho error 
    	// "lanza" una excepción de vuelta al método que lo invocó.
        
        // El resto de código después de la instrucción que produjo la excepción no se 
    	// ejecutará. El segundo método puede capturar esa excepción y si es posible 
    	// corrige la situación de error y continúa con la ejecución. Este mecanismo 
    	// proporciona la posibilidad al programador de escribir un gestor que trate
        // con la excepción.

        // Ejemplo
        
        // Declaramos una variable de Mensaje
        String[] mensaje = new String[2];
        mensaje[0]="Hola ";
        mensaje[1]="mundo!";
        
        // Generamos un error al tratar de acceder a un indice fuera de rango
        //for (int i=0;i<3;i++)
        //    System.out.println(mensaje[i]);
        
        //System.out.println("Fin");
            
        // Sentencias Try y Catch
        // Para capturar una excepción en particular hay que colocar el código que puede 
        // lanzar dicha excepción dentro de un bloque try, entonces se crea una lista de 
        // bloques catch adyacentes, uno para cada posible excepción que se quiera capturar.
        // El código de un bloque catch se ejecuta cuando la excepción generada coincide en
        // tipo con la del bloque catch. 
        // La sentencia finally define un bloque de código que se ejecuta siempre, 
        // independientemente de si una excepción fue capturada o no.Sintaxis:
        
        // try
        // {
        //      codigo que puede lanzar una excepcion en particular
        // }
        // catch (ExcepcionConocida e)
        // {
        //    codigo a ejecutar si se lanza una excepcion ExcepcionConocida
        // }
        // catch (Exception e)
        // {
        //   codigo a ejecutar si se lanza una excepcion generica: Exception
        // }
        // finally
        // {
        //    codigo a ejecutar se haya o no generado una excepcion
        // }
        
        
        
        // Ahora generamos el mismo error pero capturando la excepcion
        //try {
        //      for (int i=0;i<3;i++)
        //          System.out.println(mensaje[i]);    
        //}
        //catch (ArrayIndexOutOfBoundsException e){
        //   System.out.println("Error en Indice del Arreglo:"+e.toString());        
        //}
        //catch (Exception e){
        //     System.out.println("Error al Procesar Arreglo:"+e.toString());        
        //}
        
        //finally{
        //     System.out.println("Fin");        
        // }
        
        // Excepciones más frecuentes
        // El lenguaje Java proporciona una serie de excepciones predefinidas. A continuación 
        // se citan las más comunes:
        
        // - ArithmeticException. Es el resultado de dividir por cero números enteros:
        // int i = 12 / 0;
        
        // - NullPointerException. Intento de acceder a los atributos o métodos de un objeto
        // cuando todavía no está instanciado:
        // Date d = null;        
        // System.out.println(d.toString());
        
        // - NegativeArraySizeException. Intento de creación de un vector con un número 
        // negativo de elementos.
        
        // - ArrayIndexOutOfBoundsException. Intento de acceso a un elemento de un array 
        // fuera de rango.
        
       
        //--------------------------------------
        // Ubicación para tratar las Excepciones
        // La palabra reservada throws.
        //--------------------------------------
        
        // Cuando se declara un método es posible indicar que excepciones no serán tratadas
        // por el; y que obligarán a ser manejadas por un método padre.
        
        // Cuando se escribe un método a continuación se escribe la palabra throws
        // y posteriormente una lista de todas las excepciones que se pueden dar dentro del 
        // método y no serán gestionadas por él.
        
        // Al tratar de usar el método se nos obligará a usar try y catch
        // El Método debe estar en otra clase para que esta obligación exista
        
        Alumno xAlumno;
        try 
        {
			xAlumno = new Alumno("Juan","Perez",0);
			xAlumno.setNombre("");
		} 
        catch (Exception e) 
        {
        	// Imprime el Mensaje 
        	System.out.println("Error Capturado \n");
        	
			// TODO Auto-generated catch block
			e.printStackTrace();
		}        
        
        System.out.println("Empieza...");
    		@SuppressWarnings("unused")
			int xInt;
    		
        	// Trata de Convertir a Entero
    	    xInt=Integer.getInteger("123");

    }
}
