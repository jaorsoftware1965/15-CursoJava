class AlumnoSpecial 
{
    @SuppressWarnings("unused")
	private String  nombre;
    @SuppressWarnings("unused")
	private String  apellido;
    @SuppressWarnings("unused")
	private Integer edad;
 
    public AlumnoSpecial(String nombre, String apellido, Integer edad) throws clsMyNameErrorException 
    {
    	
       this.nombre = nombre;
       this.apellido = apellido;
       if (nombre.equals("JAOR"))
       {
           throw new clsMyNameErrorException("El nombre JAOR no está disponible");
       }else
           if (edad<=0)
        	   throw new clsMyNameErrorException("La Edad no puede ser menor o igual que 0");
           else 
               this.edad = edad;
        
    }    
}

@SuppressWarnings("serial")
class clsMyNameErrorException extends Exception
{
    private String strMensaje;
    public clsMyNameErrorException (String strMensaje)
    {
        this.strMensaje = strMensaje;
    }
    
    // Método para devolver el Error de la Excepción
    public String getMotivo()
    {
        return strMensaje;
    }
    
    // Reescribo el Método de Exception
    public String getMessage()
    {
        return strMensaje;
    }
}

public class c27_excepciones_usuario {
    @SuppressWarnings("unused")
	public static void main(String[] args) {
        
        // Clase 27. ExcepcionesII. Excepciones de Usuario
    	
        // Es posible en Java, definir nuestra propias excepciones.
    	// Las excepciones definidas por usuario se crean heredando 
    	// de la clase Exception.

    	// Estas clases pueden contener cualquier cosa al igual que 
    	// una clase estandar. 
        
        // Para lanzar una excepción creada por el usuario se utiliza la sentencia throw 
    	// como se muestra en el ejemplo siguiente:
    	
        // throw new clsMyNameErrorException("Nombre Inaceptable");
        
        // A continuación se muestra un ejemplo de excepción definida por el usuario, 
    	// con su constructor, 
        // algunas variables y métodos:
        
        // Captura la Excepción
    	try 
    	{
    		// Creando un Objeto de la Clase que utiliza la Excepción Creada
			AlumnoSpecial xAlumno=new AlumnoSpecial("JAO_R","PEREZ",0);
		
    	} 
    	catch (clsMyNameErrorException e) 
    	{
			// TODO Auto-generated catch block
			System.out.println("Error al Procesar Nombre:"+e.getMessage());
			System.out.println("Error al Procesar Nombre:"+e.getMotivo());
			
		}
    	  
    }
}