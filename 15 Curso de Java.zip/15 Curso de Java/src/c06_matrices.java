import java.util.Arrays;
public class c06_matrices {

    public static void main(String[] args) {
        // Clase 06. Matrices
        // Una matriz es un arreglo o vector de 2 dimensiones; es un conjunto de "n" espacios en memoria dispuestos para 
        // almacenar información del mismo tipo y en donde a cada elemento se le accede a través de 2 índices. 
        // El ejemplo clásico para explicar el concepto de matriz, es el plano cartesiano; en donde para ubicar un punto
        // se necesita indicar el valor para el eje x y el valor para el eje y
        // Uso de DEBUG
                
        // Arreglo para el Plano Cartesiano
        int[][] intMatrizPlanoCartesiano;
        intMatrizPlanoCartesiano = new int[4][2];
        
        // Lo anterior tambien puede escribirse en una sola línea
        int[][] intMatrizPlanoCartesiano2 = new int[8][5];
        
        // La tercera definición
        int[][] intMatrizPlanoCartesiano3 = {{11,12,13},{21,22,23},{31,32,33}};
                
        
        // Imprimo el plano cartesiano
        intMatrizPlanoCartesiano3[0][0]=90;
        System.out.println("Posición 0,0:"+intMatrizPlanoCartesiano3[0][0]);
        System.out.println("Posición 0,1:"+intMatrizPlanoCartesiano3[0][1]);
        System.out.println("Posición 0,2:"+intMatrizPlanoCartesiano3[0][2]);        
        System.out.println("Posición 1,0:"+intMatrizPlanoCartesiano3[1][0]);
        System.out.println("Posición 1,1:"+intMatrizPlanoCartesiano3[1][1]);
        System.out.println("Posición 1,2:"+intMatrizPlanoCartesiano3[1][2]);
        System.out.println("Posición 2,0:"+intMatrizPlanoCartesiano3[2][0]);
        System.out.println("Posición 2,1:"+intMatrizPlanoCartesiano3[2][1]);
        System.out.println("Posición 2,2:"+intMatrizPlanoCartesiano3[2][2]);
        
        // Métodos o Funciones que tenemos disponibles
        System.out.println("Cuantos elementos en Matriz 1:"+intMatrizPlanoCartesiano.length);
        System.out.println("Cuantos elementos en Matriz 1:"+intMatrizPlanoCartesiano[0].length);
        System.out.println("Cuantos elementos en Matriz 2:"+intMatrizPlanoCartesiano2.length);
        System.out.println("Cuantos elementos en Matriz 2:"+intMatrizPlanoCartesiano2[0].length);
        System.out.println("Cuantos elementos en Matriz 3:"+intMatrizPlanoCartesiano3.length);
        System.out.println("Cuantos elementos en Matriz 3:"+intMatrizPlanoCartesiano3[0].length);
        
        // Funciones para los arreglos
        Arrays.sort(intMatrizPlanoCartesiano3[0]);                        
        
        // Llenando el vector con el elemento indicado
        Arrays.fill(intMatrizPlanoCartesiano3[0], 77);
        Arrays.fill(intMatrizPlanoCartesiano3[1], 88);
        Arrays.fill(intMatrizPlanoCartesiano3[2], 99);
        
        
        // Imprimo el plano cartesiano
        System.out.println("Posición 0,0:"+intMatrizPlanoCartesiano3[0][0]);
        System.out.println("Posición 0,1:"+intMatrizPlanoCartesiano3[0][1]);
        System.out.println("Posición 0,2:"+intMatrizPlanoCartesiano3[0][2]);        
        System.out.println("Posición 1,0:"+intMatrizPlanoCartesiano3[1][0]);
        System.out.println("Posición 1,1:"+intMatrizPlanoCartesiano3[1][1]);
        System.out.println("Posición 1,2:"+intMatrizPlanoCartesiano3[1][2]);
        System.out.println("Posición 2,0:"+intMatrizPlanoCartesiano3[2][0]);
        System.out.println("Posición 2,1:"+intMatrizPlanoCartesiano3[2][1]);
        System.out.println("Posición 2,2:"+intMatrizPlanoCartesiano3[2][2]);
        
        
        // Veririca que sean iguales
        System.out.println(Arrays.equals(intMatrizPlanoCartesiano3[0], intMatrizPlanoCartesiano[0]));
        System.out.println(Arrays.equals(intMatrizPlanoCartesiano3[0], intMatrizPlanoCartesiano3[1]));
        System.out.println(Arrays.equals(intMatrizPlanoCartesiano3[0], intMatrizPlanoCartesiano3[0]));
        
    }
}
