
public class c29_enumerados 
{
	// Defino un Enumerado para los Días de la Semana
	enum DiasSemana
	{
		Domingo,
		Lunes,
		Martes,
		Miercoles,
		Jueves,
		Viernes,
		Sabado	
	}
		
	// Función Principal
    @SuppressWarnings("incomplete-switch")
	public static void main(String[] args) 
    {
    	
		/* 
        Curso de Programación con Java
        Clase 29. Enumerados
        Derechos Reservados JaorSoftware 2015
        www.jaorsoftware.cu.cc
	    	    
	    Un enum, también llamado Enumeración o Enumerado, es un tipo de dato definido por el 
	    usuario que solo puede tomar como valores los definidos en una lista.

        Un enum se declara de forma general de la siguiente forma:
        
        // Declaración de un Enumerado
        enum nombreEnumerado 
        {
            NombreValor1, 
            NombreValor2, 
            NombreValor3, 
            ...
            NombreValorN
        }
        
        Una vez que se ha declarado el Enumerado, es posible ya declarar variables utilizando
        su nombre, como cualquier otro tipo de dato. Ejemplo:
        
        // Variable del Enumerado
        nombreEnumerado xVariable;
        
        Una vez que tenemos la variable declarada, es posible asignarle valores utilizando
        el nombre del Enumerado y cualquiera de los valores definidos; utilizando un "." para
        acceder a ellos. Ejemplo:
        
        // Asignamos Valores a la Variable
        xVariable = nombreEnumerado.NombreValor1;
                
        Un Enumerado puede ser declarado dentro o fuera de una clase, pero no dentro de un método.
        No es posible declarar un enum dentro de un método main (programa principal); si lo hacemos
        nos saltará el error de compilación.
        Por tanto el tipo enumerado lo declararemos o bien antes del public class;o bien después
        del public class; pero fuera de cualquier método o constructor. 
        
	    */    	
    	
    	// Declaramos una variable del Enumerado
    	DiasSemana xDia=DiasSemana.Domingo;
    	    	
        // Mensaje de la Clase
        System.out.println("Curso de Java");
        System.out.println("Clase 29 - Enumerados\n");
        
        // Desplegando los elementos del Arreglo con for extendido
        System.out.println("Desplegando El valor del Enumerado");
        System.out.println(xDia);
            	
    	// Modifica el Día
    	xDia = DiasSemana.Miercoles;
    	
        // Desplegando los elementos del Arreglo con for extendido
        System.out.println("Desplegando El valor del Enumerado");
        System.out.println(xDia);
        
        // Utilizando el Enum en un switch
        switch(xDia)
        {
	        case Domingo:        
	        	 System.out.println("Descanso 2\n");
	             break;  
	             
	        case Lunes:
	             System.out.println("Inicio de Semana\n");
	             break;        
	  
	        case Miercoles:
	             System.out.println("Mitad de Semana\n");
	             break;        
	  
	        case Viernes:
	             System.out.println("Gracias a Dios es Viernes\n");
	             break;        
      
	        case Sabado:
	             System.out.println("Descanso 1\n");
	             break;        
     
        }
        
        // Verificando con if
        if(xDia==DiasSemana.Miercoles)
        	
        	// Mensaje
        	System.out.println("Ir al Cine \n");
        	
        
        // Desplegando los Valores del Enumerado
        for(DiasSemana xDia2 : DiasSemana.values()) 
        {
        	// Desplegamos la Información de Cada Valor
        	System.out.println("Dia Semana:"+xDia2.toString() + "; Su Ordinal: " + xDia2.ordinal());
        	System.out.println("Su Nombre:" +xDia2.name());
        	System.out.println("----------------------");
        }
    }


}
