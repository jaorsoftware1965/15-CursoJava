import java.util.ArrayList;


public class c31_arraylist 
{
	
	// Función Principal
    @SuppressWarnings("unchecked")
	public static void main(String[] args) 
    {
    	
		/* 
        Curso de Programación con Java
        Clase 31. ArrayList
        Derechos Reservados JaorSoftware 2015
        www.jaorsoftware.cu.cc
	    	    
        Hemos visto en Clases anteriores el Manejo de Arreglos; en los cuales
        es fácil detectar que una limitante importante, es que no existe una
        forma para aumentar o decrementar la capacidad de su memoria; es decir
        que cuando definimos un Arreglo de 10 Elementos; siempre tendremos este
        tamaño fijo para el Vector; y esto puede significar el desperdicio a la
        memoria, al tener reservada memoria que no se esté utilizando; aunque
        existen "trucos" para poder resolver este inconveniente.
        
        Para resolver esto, java tiene una CLASE llamada ArrayList que permite
        resolver esta problemática y que implementa muchos métodos que son 
        cotidianamente necesarios en la programación de un Arreglo.
        
        La Definición mas sencilla de un ArrayList es la siguiente:
        Es una Clase que implementa una Estructura de Datos, que permite cambiar
        su tamaño en forma dinámica; es decir que puede ser aumentada o disminuida.
        
        Los objetos ArrayList son creados con un tamaño inicial, y cuando se le
        agregan elementos y se necesita mas tamaño, el ArrayList es automáticamente
        incrementado; y cuando los elementos son eliminados; el objeto disminuye
        en su Tamaño.
        
        Otra caracteristica adicional, es que en un Objeto ArrayList pueden almacenarse
        elementos de distinto tipo; y no necesariamente de uno solo.
        
        La Sintaxis para definir un objeto ArrayList es la siguiente:
        
        ArrayList [<tipo>] nombreArray = new ArrayList();
        
        Donde:
        
        ArrayList. Es la Clase
        <tipo>. Se puede estipular que el ArrayList maneje objetos de un solo tipo
        nombreArray. Nombre del Objeto array
        
                
	    */    	
    	  
    	
        // Mensaje de la Clase
        System.out.println("Curso de Java");
        System.out.println("Clase 31 - ArraList \n");
        
        // Definiendo ArrayList
        @SuppressWarnings("rawtypes")
		ArrayList <String> alStrNombres= new ArrayList();        
        
        // Imprime la capacidad
        System.out.println("Tamaño Inicial:"+alStrNombres.size());
        System.out.println("");
        
        // Agregamos Elementos
        alStrNombres.add("Juan");
        alStrNombres.add("José");
        alStrNombres.add("María");
        alStrNombres.add("Jesus");
        
        // Imprime la capacidad
        System.out.println("Tamaño Inicial:"+alStrNombres.size());
     
        // Ciclo para Imprimir los Elementos
        System.out.println("Elementos del ArrayList:"+alStrNombres.size());     
        for (int iCuenta=0; iCuenta<alStrNombres.size();iCuenta++)
            // Imprimimos un Elemento específico
            System.out.println(alStrNombres.get(iCuenta));
        System.out.println("");
        
        
        // Eliminamos un Elemento
        alStrNombres.remove(3);
        alStrNombres.remove("José");
             
        // Ciclo para Imprimir los Elementos
        System.out.println("Elementos del ArrayList:"+alStrNombres.size());     
        for (int iCuenta=0; iCuenta<alStrNombres.size();iCuenta++)
            // Imprimimos un Elemento específico
            System.out.println(alStrNombres.get(iCuenta));
                
                
        // Definiendo ArrayList Genérico
        @SuppressWarnings("rawtypes")
		ArrayList alGenerico= new ArrayList();
                
        // Agrega Elementos distintos
        alGenerico.add(30);
        alGenerico.add("José");
        alGenerico.add('A');
        alGenerico.add(30);
        alGenerico.add("Juan");
        alGenerico.add('B');
                       
        // Ciclo para Imprimir los Elementos
        System.out.println("Elementos del ArrayList Genérico:"+alGenerico.size());     
        for (int iCuenta=0; iCuenta<alGenerico.size();iCuenta++)
            // Imprimimos un Elemento específico
            System.out.println(alGenerico.get(iCuenta));
        
        System.out.println("");
        
        
        // Buscar un Elemento
        System.out.println(alGenerico.contains('A'));

        // Buscar un Elemento
        System.out.println(alGenerico.contains("José"));
        
        // Buscar un Elemento
        System.out.println(alGenerico.contains("Elena"));
        System.out.println("");
        
        // Busca un objeto y Obtiene su posición
        System.out.println(alGenerico.indexOf(30));
        System.out.println(alGenerico.indexOf('A'));
        System.out.println(alGenerico.lastIndexOf(30));
        System.out.println(alGenerico.indexOf(45));
        System.out.println("");
        
        // Elimina todos los Elementos
        alGenerico.clear();
        
        System.out.println("Tamaño del Genérico:"+alGenerico.size());
        System.out.println("");
        
        
    }


}
